#!/usr/bin/env python
# coding: utf-8

# > *Alberto Ferrari* - [github](https://albertoferrari.github.io/)

# ## sequenze

# ### liste

# In[ ]:


lista_spesa = ["burro", "uova", "fagioli"]

piovosità = [13, 24, 18, 15]

mesi = ["Gen", "Feb", "Mar",
          "Apr", "Mag", "Giu", 
          "Lug", "Ago", "Set", 
          "Ott", "Nov", "Dic"]

print(lista_spesa)
print(piovosità)
print(mesi)


# In[ ]:


n = len(mesi)                       
print('numero mesi',n)
print('mesi[3] = ',mesi[3])            # "Apr"
print('mesi[-2] = ',mesi[-2])          # "Nov", -2 identico a n - 2
print('mesi[n-2] = ',mesi[n-2]) 
print('mesi[10] = ',mesi[10])


# In[ ]:


lista_spesa = ["burro", "uova", "fagioli"]
print(lista_spesa)
lista_spesa[1] = "ketchup"             # modifica un elemento
print(lista_spesa)


# In[ ]:


lista_spesa = ["burro", "uova", "fagioli"]
print('lista_spesa = ', lista_spesa)
print('"uova" in lista_spesa = ',"uova" in lista_spesa)           # True

lista_spesa.append("bacon")                             # aggiunge in coda
print('lista_spesa dopo append = ', lista_spesa)
lista_spesa.pop()                                  # elimina (e restituisce) l'ultimo elemento
print('lista_spesa dopo pop = ', lista_spesa)
lista_spesa.insert(1, "bacon")                     # sposta gli elementi successivi
print('lista_spesa dopo insert = ', lista_spesa)
eliminato = lista_spesa.pop(1)                     # elimina (e restituisce) elemento 1
print('elemento eliminato = ',eliminato)
print('lista_spesa dopo eliminazione = ', lista_spesa)
lista_spesa.remove("uova")                         # elimina l'elemento in base al valore
print('lista_spesa dopo eliminazione = ', lista_spesa)


# ### slice

# In[ ]:


mesi = ["Gen", "Feb", "Mar", "Apr", "Mag", "Giu", "Lug", "Ago", "Set", "Ott", "Nov", "Dic"]
print('mesi = ',mesi)
primavera = mesi[2:5]       # ["Mar", "Apr", "Mag"]
print('primavera =', primavera)
primi3 = mesi[:3]           # ["Gen", "Feb", "Mar"]
print('primi 3 =', primi3)
ultimi3 = mesi[-3:]         # ["Ott", "Nov", "Dic"]
print('ultimi 3 =', ultimi3)
copia_mesi = mesi[:]        # Copia in una nuova lista
print('copia_mesi =', copia_mesi)


# In[ ]:


lista1 = ["burro", "uova", "fagioli"]
lista2 = ["carne", "pesce"]
lista_spesa = lista1 + lista2     # Concatenatione
print('lista_spesa =', lista_spesa)

ripetizioni = [1, 2] * 3          # [1, 2, 1, 2, 1, 2]
print('ripetizioni =', ripetizioni)

dieciZeri = [0] * 10
print('dieciZeri =', dieciZeri)


# ### uguaglianza e identità

# In[ ]:


a = [3, 4, 5]
print('a = ',a)
b = a[:]       # b = [3, 4, 5] -- a new list!
print('b = ',b)
b == a         # True, they contain the same values
print('b == a ',b == a)
b is a         # False, they are two objects in memory
               # (try and modify one of them...) 
print('b is a ',b is a)
c = a
print('c = ',c)
print('c is a ',c is a)
c is a         # True, same object in memory 
               # (try and modify one of them...)


# In[ ]:


a = [3,4,6]
b = a    # due nomi della stessa lista
c = a[:] # copia degli elementi
a[0] = 1000
print(a)
print(b)
print(c)


# ### Liste - funzioni

# In[ ]:


# append
print('append - Adds an element at the end of the list')
fruits = ["apple", "banana", "cherry"]
fruits.append("orange")
print(fruits)
print('________________________________________________')

# clear
print('clear - Remove all elements from the list')
fruits.clear()
print(fruits)
print('________________________________________________')

# copy
print('copy - Returns a copy of the list')
fruits = ["apple", "banana", "cherry"]
x = fruits.copy()
print(x)
print('________________________________________________')

# count
print('count - Returns the number of elements with the specified value')
num = [1, 4, 2, 9, 7, 8, 9, 3, 1]
n = num.count(9)
print(n)
print('________________________________________________')

# extend
print('extend - Add the elements of a list (or any iterable), to the end of the current list')
a = ['apple', 'banana', 'cherry']
b = ['orange', 'melon']
a.extend(b)
print(a)
print('________________________________________________')

# index
print('index - Returns the index of the first element with the specified value')
num = [4, 55, 64, 32, 16, 32]
n = num.index(32)
print(n)
print('________________________________________________')

# insert
print('insert - Adds an element at the specified position')
fruits = ['apple', 'banana', 'cherry']
fruits.insert(1, "orange")
print(fruits)
print('________________________________________________')

# pop
print('pop - Removes the element at the specified position')
fruits = ['apple', 'banana', 'cherry']
fruits.pop(1)
print(fruits)
print('________________________________________________')

# remove
print('remove - Removes the first item with the specified value')
fruits = ['apple', 'banana', 'cherry']
fruits.remove("banana")
print(fruits)
print('________________________________________________')

# reverse
print('reverse - Reverses the order of the list')
fruits = ['apple', 'banana', 'cherry']
fruits.reverse()
print(fruits)
print('________________________________________________')

# sort
print('sort - Sorts the list')
cars = ['Ford', 'BMW', 'Volvo']
cars.sort()
print(cars)
print('________________________________________________')

# sort 2
print('sort - Sorts the list - descending')
cars = ['Ford', 'BMW', 'Volvo']
cars.sort(reverse=True)
print(cars)
print('________________________________________________')

# sort 3
print('sort - Sorts the list - with a function')
def myFunc(e):
  return len(e)

cars = ['Ford', 'Mitsubishi', 'BMW', 'VW']
cars.sort(key=myFunc)
print(cars)
print('________________________________________________')


# ### stringhe e liste

# In[ ]:


txt = "Monty Python's Flying Circus"
print('txt = ',txt)
txt[0]    # 'M'
print('txt[0] = ',txt[0])
txt[1]    # 'o'
print('txt[1] = ',txt[1])
txt[-1]   # 's'
print('txt[-1] = ',txt[-1])
txt[6:12] # "Python"
print('txt[6:12] = ',txt[6:12])
txt[-6:]  # "Circus"
print('txt[-6:] = ',txt[-6:])

days = ["tue", "thu", "sat"]
print('days = ',days)
txt = "|".join(days)  # "tue|thu|sat"
print('txt = ',txt)
days = "mon|wed|fri".split("|")  # ["mon", "wed", "fri"]
print('days = ',days)


# ## ciclo for - iterazione su sequenze

# In[ ]:


corsi = ['Artificial Intelligence','Machine Learning','Deep Learning']
for c in corsi:
    print(c)


# ### for e range

# In[ ]:


# somma i numeri da 1 a 10

totale = 0
for i in range(1, 11):
    totale += i
print(totale)

# totale = 0;  i = 1
# while i < 11:
#     totale += i
#     i += 1


# ### funzioni su liste

# In[ ]:


def limitaValori(lis,limite):
   ''' fissa un limite massimo ai valori della lista lista '''
   for i in range(len(lis)):
      if lis[i] > limite:
         lis[i] = limite

def stampaValori(lis):
   for i, val in enumerate(lis):
      print('indice', i, 'valore', val)

dati = [5, 4, 2]
print(dati)
limitaValori(dati, 4)
print(dati)
stampaValori(dati)


# ## tuple

# #### packing

# In[ ]:


# Tuple packing
pt = 5, 6, "red"
print('pt = ',pt)
print('pt[0] = ',pt[0])  # 5
print('pt[1] = ',pt[1])  # 6
print('pt[2] = ',pt[2])  # "red"


# #### unpacking

# In[ ]:


# multiple assignments, from a tuple
x, y, colour = pt  # sequence unpacking
print(x,y,colour)
a, b = 3, 4
print(a,b)
a, b = b, a
print(a,b)


# ## call by object

# In[ ]:


def inc(f): 
   f = f + 1     # "nuova variabile"
   print(f)      # 11

a = 10 
inc(a) 
print(a)         # 10


# In[ ]:


def inc(f): 
   for i in range(0,len(f)):
      f[i] = f[i] + 1
   print(f) # [3,4,6]

a = [2,3,5] 
inc(a) 
print(a) # [3,4,6]


# ### funzioni che restituiscono più valori

# In[ ]:


def min_max(f):
   '''
   restituisce valore minimo e massimo della lista f
   '''
   minimo = massimo = f[0]
   for i in range(1,len(f)):
      if f[i] < minimo:
         minimo = f[i]
      if f[i] > massimo:
         massimo = f[i]
   return minimo, massimo

a = [2,13,5,-3,8]
x , y = min_max(a)
print("minimo: ",x," massimo: ",y)

