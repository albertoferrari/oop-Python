#!/usr/bin/env python
# coding: utf-8

# > *Alberto Ferrari* - [github](https://albertoferrari.github.io/)

# ## python - linguaggio multiparadigma

# ### paradigma imperativo - esempio

# In[ ]:


# paradigma imperativo - sequenza
# esempio: conversione da lista a stringa
lista_caratteri = ['p','y','t','h','o','n']
stringa = ''
stringa += lista_caratteri[0]
stringa += lista_caratteri[1]
stringa += lista_caratteri[2]
stringa += lista_caratteri[3]
stringa += lista_caratteri[4]
stringa += lista_caratteri[5]
print(stringa)


# In[ ]:


# paradigma imperativo - ciclo
# esempio: conversione da lista a stringa
lista_caratteri = ['p','y','t','h','o','n']
stringa = ''
for c in lista_caratteri:
    stringa += c
print(stringa)


# ### paradigma procedurale - esempio

# In[ ]:


# paradigma procedurale
# esempio: conversione da lista a stringa
def converti(lis: list) -> str:
    st = ''
    for c in lis:
        st += c
    return st
lista_caratteri = ['p','y','t','h','o','n']
print(converti(lista_caratteri))


# ### paradigma funzionale (lambda calcolo) - esempio

# In[ ]:


# paradigma funzionale
# esempio: conversione da lista a stringa
import functools
lista_caratteri = ['p','y','t','h','o','n']
stringa = functools.reduce(lambda s,c: s + c, lista_caratteri)
print(stringa)


# In[ ]:


# paradigma funzionale
# esempio: somma elementi di una lista
lista_numeri = [1,2,3,4,5]
somma = functools.reduce(lambda x,y: x + y, lista_numeri)
print(somma)


# ### paradigma ad oggetti - esempio

# In[ ]:


class op_lista:
    def __init__(self, l):
        self.lista = l
    def converti(self):
        self.stringa = ''.join(self.lista)

lista_caratteri = ['p','y','t','h','o','n']
mia_lista = op_lista(lista_caratteri)
mia_lista.converti()
print(mia_lista.stringa)

