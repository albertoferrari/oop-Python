#!/usr/bin/env python
# coding: utf-8

# > *Alberto Ferrari* - [github](https://albertoferrari.github.io/)

# #### python builtin data types
# ##### int, float,str,list,...
# sono classi in cui sono definiti una serie di metodi

# In[ ]:


help(list)      # documentazione del tipo list


# In[ ]:


primi=[1,2,3,5,7,11]        # primi è un oggetto della classe list
print(type(primi))          # class 'list'
print(primi)
primi.remove(5)             # remove è un metodo della classe list (con un parametro)
print(primi)
primi.reverse()             # reverse è un metodo della classe list (senza parametri)
print(primi)


# In[ ]:


help(list)


# ##### esempio
# classe Studente con il metodo saluta()

# In[ ]:


class Studente:
    
    def saluta(self):
        print('ciao sono uno studente')


# In[ ]:


s = Studente()
s.saluta()


# ##### aggiunta alla classe del costruttore __init__ e dell'attrobuto _nome

# In[ ]:


class Studente:

    def __init__(self, n):
        self._nome = n
        
    def saluta(self):
        print('ciao sono lo studente',self._nome)


# In[ ]:


s1 = Studente('Aldo')
s1.saluta()


# ## classe Automobile

# In[ ]:


class Automobile:

    def __init__(self, vm: int, va: int, freno: str):
        '''
        vm velocità massima
        va velocità attuale
        freno tipo freno
        '''
        self._vm = max(vm,0)
        self._va = max(va,0)
        if freno == 'tamburo':
            self._freno = 'tamburo'
        else:
            self._freno = 'disco'

    def accelera(self,km: int):
        ''' aumenta la velocià di km chilometri orari'''
        if km <= 0:
            return
        self._va += km
        if self._va > self._vm:
            self._va = self._vm
            
    def frena(self):
        ''' dipende dal tipo dei freni '''
        if self._freno == 'disco':
            self._va -= 20
        else:
            self._va -= 10
        self._va = max(self._va,0)
    
    def to_tuple(self) -> tuple:
        return self._vm, self._va, self._freno
    
    def to_string(self) -> str:
        s = 'velocità massima: ' + str(self._vm)
        s += ' velocità attuale: ' + str(self._va)
        s += ' freni a ' + self._freno
        return s

    def get_va(self) -> int:
        '''
        restituisce la velocità attuale
        '''
        return self._va
    
    def set_va(self, v: int):
        '''
        modifica le velocità attuale
        '''
        if v <= self._vm:
            self._va = v
        else:
            self._va = self._vm


# In[ ]:


a1 = Automobile(200,100,'tamburo')
velocità = a1.get_va()
print(velocità)
a1.set_va(400)
print(a1.get_va())


# ## istanziazione

# In[ ]:


mario = Automobile(220,120,'tamburo')
print(mario.to_string())
mario.accelera(5)
print(mario.to_string())
mario.accelera(500)
print(mario.to_string())
for i in range(25):
    mario.frena()
    print(mario.to_string())


# In[ ]:


kong = Automobile(300,10,'disco')
print(kong.to_string())
kong.accelera(100)
print(kong.to_string())
kong.frena()
print(kong.to_string())
kong._va = 1000
print(kong.to_string())


# ### Punto sul piano cartesiano

# In[ ]:


class Punto:
    '''
    rappresenta un punto sul piano cartesiano 
    in uno spazio bidimensionale
    '''

    def __init__(self, x: float, y: float):
        ''' 
        inizializzazione attributi (coordinate)
        '''
        self._x = x
        self._y = y

    def coordinate(self) -> (float, float):
        '''
        coordinate del punto
        '''
        return self._x, self._y

    def __str__(self) -> str:
        '''
        rappresentazione del punto
        '''
        return "(" + str(self._x) + "," + str(self._y) + ")"

    def distanza_origine(self) -> float:
        '''
        restituisce la distanza del punto dall'origine degli assi
        '''
        return (self._x**2 + self._y **2) ** 0.5

    def distanza_punto(self, p: 'Punto') -> float:
        '''
        restituisce la distanza dal punto p
        '''
        dx = self._x - p._x
        dy = self._y - p._y
        return (dx ** 2 + dy ** 2) ** 0.5
    
    def sposta(self, dx: float, dy: float):
        '''
        dx spostamento sull'asse x
        dy spostamento sull'asse y
        '''
        self._x += dx
        self._y += dy


# ### oggetti e operazioni con gli oggetti

# In[ ]:


p1 = Punto(3,4)
x , y = p1.coordinate()
# x = p1.coordinate()[0]
# y = p1.coordinate()[1]
print(p1,end=' ')
#print('punto (',x,',',y,')',end = ' ')
print("dista dall'origine",p1.distanza_origine())
p2 = Punto(5,5)
print(p1.coordinate(),"dista dal punto",p2.coordinate(),p1.distanza_punto(p2))


# ### in Python tutto è un oggetto

# In[ ]:


print('tipo di p1',type(p1)) 
n = 15                                         # viene istanziato l'oggetto n della classe int
print('tipo di n',type(n))                     # type funzione
print('rappresentazione binaria di n',bin(n))  # bin funzione
print('cifre binarie di n',n.bit_length())     # bit_lenght metodo


# In[ ]:


f = 3.25                                                 # f oggetto della classe float
print('tipo di f ',type(f))                              # type funzione
print(f.as_integer_ratio(),'frazione generatrice di',f)  # as_integer_ratio metodo


# In[ ]:


help(float.as_integer_ratio)


# In[ ]:


m = [1,3,5,7]                                         
print('tipo di m ',type(m))                              # type funzione
print('m',m)
m.reverse()                                              # reverse metodo
print('m',m)


# In[ ]:


help(list.reverse)


# In[ ]:


s = 'hello world'
print('tipo di s ',type(s))                              # type funzione
s = s.replace('o','0')                                   # replace metodo
print(s)


# ### variabili di istanza
# Ogni oggetto (istanza di una classe) dispone di attributi che sono propri di se stesso
# - gli attributi di un oggetto sono chiamati *variabili di istanza*
# - per accedere alle variabili di istanza si utilizza il riferimento *self*

# In[ ]:


class Studente:
    
    def __init__(self, nome, cognome):
        self._nome = nome
        self._cognome = cognome
    def visualizza(self):
        print(self._nome,'-',self._cognome)

s1 = Studente("Mario","Rossi")
s1.visualizza()
print(s1.__dict__)


# ### variabili di classe - costruttore - distruttore

# In[ ]:


class Gatto:
    numero_gatti = 0
    
    def __init__(self,nome: str):
        ''' costruttore '''
        self.nome = nome
        Gatto.numero_gatti += 1
        print('ora esiste il gatto',self.nome)
    
    def __del__(self):
        ''' distruttore '''
        Gatto.numero_gatti -= 1
        print('ora non esiste più il gatto',self.nome)
        
g1 = Gatto('micio')
print('gatti presenti:',Gatto.numero_gatti)
g2 = Gatto('fufi')
print('gatti presenti:',Gatto.numero_gatti)
del g1
print('gatti presenti:',Gatto.numero_gatti)
del g2
print('gatti presenti:',Gatto.numero_gatti)


# ### Composizione

# In[ ]:


class Segmento:
    def __init__(self, a: Punto, b: Punto):
        self._a = a
        self._b = b
        
    def lunghezza(self) -> float:
        return self._a.distanza_punto(self._b)
    
    def __str__(self) -> str:
        return "estremo a = " + str(self._a) + " estremo b = " + str(self._b)


# ### oggetti delle classi Punto e Segmento

# In[ ]:


p1 = Punto(1,1)
print('punto p1',p1)
print("distanza di p1 dall'origine degli assi",p1.distanza_origine())
p1.sposta(1,2)
print('dopo lo spostamento p1',p1)
print("distanza di p1 dall'origine degli assi",p1.distanza_origine())
p2 = Punto(5,7)
print('punto p2',p2)
print('distanza fra p1 e p2',p1.distanza_punto(p2))
s = Segmento(p1,p2)
print(s)
print('lunghezza=',s.lunghezza())
p1._x = 0
print('lunghezza=',s.lunghezza())


# In[ ]:




