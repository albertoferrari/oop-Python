#!/usr/bin/env python
# coding: utf-8

# > *Alberto Ferrari* - [github](https://albertoferrari.github.io/)

# ### esercizio
# Dati due valori interi, fornire come risultato il quadrato della loro differenza

# In[ ]:


x = 12
y = 23

risultato = (x-y) ** 2

print("il quadrato della differenza fra",x,"e",y,"è", risultato)


#  ### esercizio
#  Dato il perimetro di un quadrato, fornire come risultato il valore del lato e dell’area

# In[ ]:


# input
perimetro = float(input("perimetro del quadrato: "))
# elaborazione
lato = perimetro / 4
area = lato ** 2
#output
print("il quadrato con perimetro",perimetro)
print("ha il lato lungo",lato)
print("e l'area di superficie", area)


# ### esercizio
# Il gallone liquido americano è definito come 231 pollici cubi e corrisponde a circa 3.785 litri. Un gallone imperiale è equivalente a circa 1,2 galloni americani liquidi. Il gallone americano secco è una misura storicamente applicata ad un volume di grano o altri prodotti secchi<br>
# Data una quantità di litri fornire la quantità equivalente in galloni americani e galloni imperiali

# In[ ]:


# input - inserimento dei dati
litri = float(input("litri: "))

# elaborazione - corpo del programma 
galUSA = litri / 3.785
galImp = galUSA * 1.2

# output - comunico i risultati
print("galloni imperiali",galImp)
print("galloni americani",galUSA)


# ### esercizio
# Si ricevono in input due numeri interi positivi determinare se il maggiore dei due è multiplo del minore

# In[ ]:


a = int(input('primo   valore: '))
b = int(input('secondo valore: '))
if a >= b and a % b == 0:
    print(a,'è multiplo di',b)
elif b > a and b % a == 0:
    print(b,'è multiplo di',a)
else:
    print('il maggiore dei due non è multiplo del minore')


# ### esercizio
# Una società immobiliare vende appartamenti con prezzi al metro quadro dipendenti dalla distanza dal mare: 1800 euro per distanze inferiori a 200 metri, 1500 euro per distanze fino a 500 metri e 1000 euro per distanze superiori. Ricevuti in input la misura della superficie dell'appartamento in mq. e la distanza dal mare, calcolarne il prezzo.

# In[ ]:


mq = float(input('superficie: '))
distanza = int(input('distanza dal mare: '))
if distanza < 200:
    prezzo = mq * 1800
elif distanza <= 500:
    prezzo = mq * 1500
else:
    prezzo = mq * 1000
print('prezzo: ',prezzo)


# ### esercizio
# Scrivere un programma che richiede in input un numero intero positivo (se il numero non è positivo richiederlo nuovamente) e visualizza tutti i suoi divisori.

# In[ ]:


n = int(input('valore intero positivo: '))
while n <= 0:
    print('valore non corretto')
    n = int(input('valore intero positivo: '))
    
div = 1      # possibile divisore
while div <= n/2:
    if n % div == 0:
        print(n,'è divisibile per',div)
    div += 1      # possibile divisore successivo
    
print(n,'è divisibile per',n)


# ### esercizio
# Scrivere un programma che riceve in input il valore n compreso fra 2 e 20 e visualizza il valore di tutte le n potenze di 2 

# In[ ]:


n = int(input("valore nell'intervallo [2,20]: "))
while n < 2 or n > 20:
    print('valore non corretto')
    n = int(input("valore nell'intervallo [2,20]: "))
    
e = 0       # esponente
while e <= n:
    print('2 elevato a',e,'=',2 ** e)
    e += 1  # esponente successivo


# ### esercizio
# Si riceve come dato d'ingresso una sequenza di numeri interi, i numeri sono al massimo 10, non è conosciuta a priori la lunghezza di questa sequenza che termina o al raggiungimento del decimo valore o quando viene inserito il valore 0. Al termine dell’input si visualizzi la media aritmetica dei valori inseriti (non si consideri il valore 0 finale).

# In[ ]:


n = int(input('valore (0 per terminare): '))    # primo valore
c = 1           # conta quanti numeri sono stati inseriti
somma = n       # somma dei valori inseriti

while n != 0 and c < 10:
    n = int(input('valore (0 per terminare): '))   # nuovo valore
    somma += n
    if n != 0:
        c += 1
        
print('media: ',somma/c)


# ### esercizio
# Scrivere un programma che, richiesto un numero intero, stabilisca se questo è primo (Suggerimento: sfruttare l’esercizio numero 1)
# Utilizzare il programma per rispondere alla seguente domanda: quali dei seguenti numeri sono primi? 
# 96553     15983567 	17 	(Risposta: il primo e il terzo)

# In[ ]:


n = int(input('valore intero positivo: '))
while n <= 0:
    n = int(input('valore intero positivo: '))
primo = True          # per il momento il numero è primo
div = 2               # primo divisore
while div <= n / 2 and primo:
    if n % div == 0:     # trovato un divisore
        print('trovato un divisore: ', div)
        primo = False    # il numero non è primo
    div += 1
if primo:
    print(n,'è un numero primo')
else:
    print(n,'non è un numero primo')


# ### esercizio
# Sostituire tutte le vocali minuscole con '*' in una stringa ricevuta in input

# In[ ]:


s = input('stringa: ')
s = s.replace('a','*')
s = s.replace('e','*')
s = s.replace('i','*')    
s = s.replace('o','*')
s = s.replace('u','*')
print(s)

