#!/usr/bin/env python
# coding: utf-8

# > *Alberto Ferrari* - [github](https://albertoferrari.github.io/)

# ### esercizio
# La sezione aurea è definita come
# $ \phi= \frac{b}{a}=\frac{a+b}{b}= (1+\sqrt{5})/2 $
# scrivere una funzione che restituisce il valore della sezione aurea

# In[ ]:


import math

def sezione_aurea():
    '''
    valore della sezione aurea
        Returns:
            valore delle sezione aurea
    '''
    v = (1 + math.sqrt(5)) / 2
    return v

print(sezione_aurea())


# ### esercizio
# Scrivere la funzione primo che riceve come parametro un numero intero (sicuramente positivo) e restituisce True se questo è primo.
# Utilizzare la funzione per rispondere alla seguente domanda: quali dei seguenti numeri sono primi? 
# 96553  15983567 17 	(Risposta: il primo e il terzo)
# 
# <i>La funzione deve avere una docstring significativa</i>

# In[ ]:


def primo(n: int) -> bool:
    ''' 
    verifica su un numero è primo
        Parameters:
            n (int) intero positivo
        Returns:
            (bool) True se n è primo
    '''
    d = 2 # possibile divisore
    while d <= n/2:
        if n % d == 0:
            return False
        d += 1    
    return True
 
def main():    
    if primo(96553):
        print(96553,'è un numero primo')
    else:
        print(96553,'non è un numero primo')

main()


# ### esercizio
# Visualizzare la docstring della funzione precedentemente creata

# In[ ]:


help(primo)


# ### esercizio
# Scrivere la funzione volume che riceve come parametri le misure degli spigoli di un parallelepipedo rettangolo e restituisce il volume. Scrivere un programma che richiede in input le misure di un parallelepipedo rettangolo e, utilizzando la funzione volume stampa il volume.

# In[ ]:


def volume(x: float, y: float, z: float) -> float:
    ''' volume parallelepipedo rettangolo '''
    return x * y * z

def main():
    s1 = float(input('spigolo 1: '))
    s2 = float(input('spigolo 2: '))
    s3 = float(input('spigolo 3: '))
    v = volume(s1,s2,s3)
    print('volume del parallelepipedo =',v)

main()


# In[ ]:


help(volume)


# ### esercizio
# Generare 10 numeri casuali nell’intervallo [10,100] e, per ognuno di questi, visualizzare tutti i suoi divisori primi<br>
# <i>The randint(start, stop) includes both start and stop numbers while generating random integer</i><br>
# iniziare con
# from random import randint

# In[ ]:


from random import randint

c = 0                       # numero valori generati
while c < 10:
    v = randint(10,100)         # valore casuale
    print('valore generato:',v,'divisori:',end=' ')
    d = 2                       # possibile divisore di v
    while d <= v/2:
        if v % d == 0 and primo(d):
            print(d,end=' ')
        d += 1
    c += 1
    print()


# ### esercizio
# funzione che visualizza tutti i fattori primi di un numero n
# - parametro: n
# - risultato: visualizzazione dei fattori primi di n
# 
# algoritmo: scorrere tutti i valori d'interesse, e cercare i divisori
# - x è divisore di n sse n % x == 0
# 
# non considerare i fattori non primi
# 
# provare la funzione con valori inseriti dall'utente quando si trova un divisore x, dividere ripetutamente n per x, finché resta divisibile 

# In[ ]:


def fattori_primi(n: int):
    ''' 
    visualizza i fattori primi di un numero intero positivo
        Parameters:
            n (int) numero di cui si vogliono visualizzare i fattori primi
    '''
    fattori = ""
    for d in range(2,n//2+1):
        if n % d == 0 and primo(d):
            fattori += str(d) + ' '
    print(fattori)

v = int(input('valore intero positivo: '))
print('fattori primi di',v)
fattori_primi(v)

