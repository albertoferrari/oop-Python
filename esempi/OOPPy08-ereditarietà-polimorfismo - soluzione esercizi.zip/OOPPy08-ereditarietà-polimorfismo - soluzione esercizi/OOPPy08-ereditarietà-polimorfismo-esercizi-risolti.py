#!/usr/bin/env python
# coding: utf-8

# > *Alberto Ferrari* - [github](https://albertoferrari.github.io/)

# ### Ereditarietà e polimorfismo

# Un’azienda intende classificare i propri *Dipendenti* in relazione al tipo di contratto stipulato con il lavoratore.
# 
# A questo proposito distingue i lavoratori in:
# - *A_tempo*
# - *Apprendisti*
# - *In_formazione_lavoro*
# 
# Di ogni dipendente interessano il *cognome* e il *nome*.
# 
# Per i dipendenti *a_tempo* si deve memorizzare l’attributo *tipologia* che può assumere i valori: ‘determinato’, ‘indeterminato’ o ‘parziale’
# 
# Per gli *apprendisti* si deve memorizzare l’*età* (valore intero)
# 
# Per i dipendenti *in_formazione_lavoro* si deve memorizzare la *durata* del contratto (2 o 4 anni).
# 
# Realizzare la gerarchia di classi con relativi costruttori, metodi setter (impedendo la memorizzazione di dati errati) e getter e il metodo __str__.
# 
# Realizzare la classe *Azienda* che ha come attributo il *nome* dell'azienda e contiene un *elenco* di lavoratori e metodi per *aggiungere* lavoratori e *visualizzare* le informazioni relative a tutti i lavoratori presenti nell’elenco.
# 

# ![Azienda](Azienda.jpg)

# In[ ]:


class Dipendente:
    '''
    Dipendente generico
        Attributes:
            cognome (str) cognome del dipendente
            nome (str) nome del dipendente
    '''
    def __init__(self, cognome: str, nome: str):
        self._cognome = cognome
        self._nome = nome

    def get_cognome(self):
        return self._cognome

    def get_nome(self):
        return self._nome
    
    def set_cognome(self, cognome):
        self._cognome = cognome

    def set_nome(self, nome):
        self._nome = nome
        
    def __str__(self):
        return self._nome+' '+self._cognome


# In[ ]:


d = Dipendente('rossi','mario')
print(d)
print(d.get_cognome())
print(d.get_nome())
d.set_cognome('bianchi')
d.set_nome('luigi')
print(d)


# In[ ]:


class A_tempo(Dipendente):
    
    def __init__(self, cognome: str, nome: str, tipologia: str):
        super().__init__(cognome,nome)
        if tipologia in ['determinato', 'indeterminato', 'parziale']:
            self._tipologia = tipologia
        else:
            self._tipologia = 'determinato'
            
    def get_tipologia(self):
        return self._tipologia
    
    def set_tipologia(self, tipologia):
        if tipologia in ['determinato', 'indeterminato', 'parziale']:
            self._tipologia = tipologia
    def __str__(self):
        s = super().__str__() + ' tipologia '+ self._tipologia
        return s  


# In[ ]:


at = A_tempo('Gates','Bill','indeterminato')
print(at)
at.set_cognome('Clinton')
at.set_tipologia('determinato')
print(at)


# In[ ]:


class Apprendista(Dipendente):
    
    def __init__(self, cognome: str, nome: str, età: int):
        super().__init__(cognome,nome)
        self._età = abs(età)
            
    def get_età(self):
        return self._età
    
    def set_età(self, età):
        self._età = abs(età)
            
    def __str__(self):
        s = super().__str__() + ' età '+ str(self._età)
        return s


# In[ ]:


app = Apprendista('Zuckerberg', 'Mark Elliot', 30)
print(app)
app.set_età(38)
print(app)


# In[ ]:


class In_formazione(Dipendente):
    
    def __init__(self, cognome: str, nome: str, durata: int):
        super().__init__(cognome,nome)
        self.set_durata(durata)
            
    def get_durata(self):
        return self._durata
    
    def set_durata(self, durata):
        if durata == 4:
            self._durata = 4
        else:
            self._durata = 2
            
    def __str__(self):
        s = super().__str__() + ' durata formazione '+ str(self._durata) + ' anni'
        return s


# In[ ]:


inf = In_formazione('Berners-Lee', 'Timothy John', 4)
print(inf)
inf.set_durata(2)
inf.set_nome('Tim')
print(inf)


# In[ ]:


class Azienda:
    
    def __init__(self, nome: str):
        self._nome = nome
        self._elenco = []   # elenco dei dipendenti al momento vuoto

    def get_nome(self):
        return self._nome

    def set_nome(self, nome):
        self._nome = nome        
        
    def aggiungi_dipendente(self, d: Dipendente):
        if d not in self._elenco:
            self._elenco.append(d)
    
    def __str__(self):
        s = 'Azienda ' + self._nome + ' dipendenti:\n'
        for d in self._elenco:
            s += str(d) + '\n'
        return s


# In[ ]:


az = Azienda('Microsoft')
print(az)
d = Dipendente('rossi','mario')
at = A_tempo('Gates','Bill','indeterminato')
app = Apprendista('Zuckerberg', 'Mark Elliot', 30)
inf = In_formazione('Berners-Lee', 'Timothy John', 4)
# az.aggiungi_dipendente(d)
az.aggiungi_dipendente(at)
az.aggiungi_dipendente(app)
az.aggiungi_dipendente(inf)
print(az)

