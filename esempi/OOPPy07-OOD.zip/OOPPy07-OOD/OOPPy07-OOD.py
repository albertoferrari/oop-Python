#!/usr/bin/env python
# coding: utf-8

# > *Alberto Ferrari* - [github](https://albertoferrari.github.io/)

# ### esempio
# Si vogliono gestire i tornei di tennis e i tennisti partecipanti. 
# 
# Di ogni Torneo interessa la denominazione (String), il montepremi in dollari (int) e il vincitore (Tennista). 
# 
# Di ogni Tennista interessa il nome (String), il numero di tornei vinti (int) e il montepremi vinto (int).
# 
# La istanziazione di un torneo implica obbligatoriamente che venga specificata la denominazione e il montepremi mentre il vincitore rimane non specificato.
# 
# La istanziazione di un tennista implica obbligatoriamente che venga specificato il solo nome mentre il numero di tornei vinti e il montepremi vinto sono posti a 0.
# 
# Il torneo ha il metodo vincitore che prende come parametro un tennista e conseguentemente aggiorna gli attributi del tennista (numero di tornei vinti e il montepremi).

# ### class diagram
# ![tennis class diagram](tennis.jpg)

# In[ ]:


class Tennista:
    '''
    classe che rappresenta un tennista
        Attributes:
            _nome (str) nome del tennista
            _tornei_vinti (int) numero di tornei vinti
            _montepremi_vinto (int) importo totale in dollari dei tornei vinti
        Methods:
            ...
    '''
    def __init__(self, nome: str):
        self._nome = nome
        self._tornei_vinti = 0
        self._montepremi_vinto = 0
        
    def vincita_torneo(self,premio :int):
        '''
        registra la vittoria in un torneo e il premio relativo
            Parameters:
                premio (int) importo del premio vinto nel torneo
        
        '''
        self._tornei_vinti += 1
        self._montepremi_vinto += premio
        
    def get_nome(self) -> str:
        return self._nome
    
    def get_tornei_vinti(self) -> int:
        return self._tornei_vinti
    
    def get_montepremi_vinto(self) -> int:
        return self._montepremi_vinto
    
    def __str__(self) -> str:
        s =  self._nome+' ha vinto '+str(self._tornei_vinti)
        s += ' tornei e '+str(self._montepremi_vinto)+' dollari'
        return s


# In[ ]:


t1 = Tennista('Federer')
t1.vincita_torneo(5000)
t1.vincita_torneo(20000)
print(t1)
print(t1.get_nome())
print(t1.get_tornei_vinti())
print(t1.get_montepremi_vinto())


# In[ ]:


class Torneo:
    '''
    classe che rappresenta un torneo di tennis
    Attributes:
        denominazione (str) denominazione del torneo
        montepremio (int) premio per il vincitore in dollari
        vincitore (Tennista) tennista vincitore del torneo
    Methods:
        ...
    '''
    def __init__(self, denominazione: str, premio: int):
        self._denominazione = denominazione
        self._montepremio = premio
        self._vincitore = None    # nessun vicitore
        
    def __str__(self) -> str:
        s = 'torneo '+self._denominazione
        s += ' montepremio '+str(self._montepremio)+'$'
        if self._vincitore != None:
            s += ' vinto da '+str(self._vincitore.get_nome())
        return s
    
    def get_vincitore(self) -> Tennista:
        return self._vincitore
    
    def vincitore(self, t: Tennista):
        if self._vincitore == None:
            t.vincita_torneo(self._montepremio)
            self._vincitore = t


# In[ ]:


wimbledon = Torneo('Wimbledon',100000)
print(wimbledon)
wimbledon.vincitore(t1)
print(wimbledon)
print(t1)
print('il vincitore del torneo è',wimbledon.get_vincitore())

