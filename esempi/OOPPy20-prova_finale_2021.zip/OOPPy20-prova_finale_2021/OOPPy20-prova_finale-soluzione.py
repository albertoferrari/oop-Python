#!/usr/bin/env python
# coding: utf-8

# ### CISITA – OOP Python – prova finale (19/03/2021) ###
# **Durata della prova 2 ore: indicazioni**
# La soluzione al problema deve essere scritta in linguaggio Python e memorizzata in uno o più file con estensione .py o in alternativa un unico file con estensione. ipynb (file di Jupyter Notebook)
# In ogni caso il tutto deve essere compresso in un unico file .zip e inviato come allegato all’indirizzo alberto.ferrari@unipr.it e l’oggetto del messaggio deve contenere il vostro nome e cognome.
# 
# Problema: treni a guida autonoma
# Ogni treno ha una sigla (stringa) ed è composto da una locomotiva e da un certo numero di vagoni.
# Si definisca la gerarchia di classi con classe base Vagone e sottoclasse Vagone_merci e Vagone_passeggeri.
# 
# La classe Vagone ha gli attributi lunghezza in metri (float) e peso_a_vuoto in tonnellate (float) e, oltre al costruttore, i metodi setter e getter, il metodo str e il metodo get_peso_totale che restituisce il peso a vuoto del vagone. Non sono ammessi valori negativi per gli attributi.
# 
# La classe Vagone_merci ha l’attributo peso_caricato (float) che contiene il valore in tonnellate delle merci caricate sul vagone e l’attributo peso_trasportabile (float) che stabilisce il limite massimo delle tonnellate caricabili sul vagone. Oltre al costruttore e al metodo str definire anche i metodi getter e gli eventuali altri metodi opportuni. I valori devono essere positivi e accettabili peso_caricato <= peso_trasportabile.
# 
# La classe Vagone_passeggeri ha l’attributo passeggeri (int) che rappresenta quanti passeggeri sono presenti sul vagone e l’attributo capienza (int) che rappresenta il numero massimo di passeggeri che possono salire sul vagone. Oltre al costruttore e al metodo str definire anche i metodi getter e i metodi sale_passeggero e scende_passeggero che incrementano o decrementano di uno il numero di passeggeri presenti (mantenendo valori accettabili).
# 
# La classe Treno ha i seguenti attributi:
# - sigla (str) identificativo del treno
# - lunghezza_locomotiva (float) che rappresenta la lunghezza in metri della locomotiva
# - peso_locomotiva (float) che rappresenta il peso della locomotiva in tonnellate 
# - composizione (list) che contiene i vagoni che compongono il treno
# 
# e i seguenti metodi:
# - il cotruttore che riceve i parametri sigla, lunghezza_locomotiva e peso_locomotiva e imposta composizione a lista vuota
# - il metodo str che restituisce una stringa con tutte le informazioni associate al treno e ai vagoni presenti
# - il metodo aggiungi_vagone che aggiunge un vagone al treno 
# - il metodo lunghezza_totale che restituisce la lunghezza totale del treno comprensiva dei relativi vagoni
# - il metodo peso_totale che restituisce il peso totale del treno e dei relativi vagoni
# 
# Per convenzione si ipotizza il peso medio di un passeggero in 80 chilogrammi.
# 
# Testare i metodi delle varie classi.

# ### diagramma delle classi ###
# ![Diagramma delle classi](treni.jpg)

# In[ ]:


class Vagone:
    
    def __init__(self, lunghezza: float, peso_a_vuoto: float):
        self._lunghezza = abs(lunghezza)
        self._peso_a_vuoto = abs(peso_a_vuoto)
        
    def set_lunghezza(self, lunghezza: float):
        self._lunghezza = abs(lunghezza)
        
    def get_lunghezza(self) -> float:
        return self._lunghezza
    
    def set_peso_a_vuoto(self, peso_a_vuoto: float):
        self._peso_a_vuoto = abs(peso_a_vuoto)
        
    def get_peso_a_vuoto(self) -> float:
        return self._peso_a_vuoto
    
    def peso_totale(self) -> float:
        return self._peso_a_vuoto
    
    def __str__(self) -> str:
        return 'lunghezza: '+str(self._lunghezza)+' peso a vuoto: '+str(self._peso_a_vuoto)


# In[ ]:


class Vagone_merci(Vagone):
    
    def __init__(self, lunghezza: float, peso_a_vuoto: float, caricato: float, trasportabile: float):
        super().__init__(lunghezza, peso_a_vuoto)
        self._peso_trasportabile = abs(trasportabile)
        self._peso_caricato = min(abs(caricato),self._peso_trasportabile)
    
    def get_peso_caricato(self) -> float:
        return self._peso_caricato
    
    def get_peso_trasportabile(self) -> float:
        return self._peso_trasportabile   
         
    def peso_totale(self) -> float:
        return super().peso_totale() + self._peso_caricato
    
    def __str__(self) -> str:
        s = 'vagone merci '+super().__str__()
        s += ' peso caricato: '+str(self._peso_caricato)
        s += ' peso massimo trasportabile '+str(self._peso_trasportabile)
        return s


# In[ ]:


class Vagone_passeggeri(Vagone):

    def __init__(self, lunghezza: float, peso_a_vuoto: float, passeggeri: int, capienza: int):
        super().__init__(lunghezza, peso_a_vuoto)
        self._capienza = abs(capienza)
        self._passeggeri = min(abs(passeggeri),self._capienza)    

    def get_passeggeri(self) -> float:
        return self._passeggeri
    
    def get_capienza(self) -> float:
        return self._capienza
         
    def peso_totale(self) -> float:
        return super().peso_totale() + self._passeggeri * 80 / 1000
    
    def sale_passeggero(self):
        if self._passeggeri < self._capienza:
            self._passeggeri += 1
            
    def scende_passeggero(self):
        if self._passeggeri > 0:
            self._passeggeri -= 1
        
    def __str__(self) -> str:
        s = 'vagone passeggeri '+super().__str__()
        s += ' passeggeri presenti: '+str(self._passeggeri)
        s += ' capienza massima '+str(self._capienza)
        return s


# In[ ]:


class Treno:
    
    def __init__(self, sigla: str, lunghezza_locomotiva: float, peso_locomotiva: float):
        self._sigla = sigla
        self._lunghezza_locomotiva = abs(lunghezza_locomotiva)
        self._peso_locomotiva = abs(peso_locomotiva)
        self._composizione = []

    def aggiungi_vagone(self, vag: Vagone):
        self._composizione.append(vag)        

    def lunghezza_totale(self) -> float:
        lung = self._lunghezza_locomotiva
        for v in self._composizione:
            lung += v.get_lunghezza()
        return lung
    
    def peso_totale(self) -> float:
        p = self._peso_locomotiva
        for v in self._composizione:
            p += v.peso_totale()
        return p
        
    def __str__(self) -> str:
        s = 'treno '+self._sigla
        s += ' locomotiva lunghezza: '+ str(self._lunghezza_locomotiva)
        s += ' peso: ' + str(self._peso_locomotiva) + ' vagoni:'
        for v in self._composizione:
            s += '\n'+str(v)
        return s


# In[ ]:


v = Vagone(12.5, -33.5)
print(v)
v.set_lunghezza(-13)
v.set_peso_a_vuoto(11)
print(v.get_lunghezza())
print(v.get_peso_a_vuoto())
print(v.peso_totale())
print(v)


# In[ ]:


vm = Vagone_merci(18.5,12,33,28)
print(vm.peso_totale())
print(vm)


# In[ ]:


vp = Vagone_passeggeri(19.2,10,55,57)
vp.sale_passeggero()
print(vp)
print(vp.peso_totale())
vp.sale_passeggero()
vp.sale_passeggero()
vp.sale_passeggero()
vp.sale_passeggero()
print(vp)
vp.scende_passeggero()
print(vp)


# In[ ]:


t = Treno('xx123',12,15)
t.aggiungi_vagone(vm)
t.aggiungi_vagone(vp)
print(t)
print(t.lunghezza_totale())
print(t.peso_totale())

