#!/usr/bin/env python
# coding: utf-8

# > *Alberto Ferrari* - [github](https://albertoferrari.github.io/)

# ### esercizio
# 
# - Inserire nella lista *province* la sigla (due caratteri) delle 8 province dell'emilia romagna (https://www.tuttitalia.it/emilia-romagna/89-province/) in ordine alfabetico (BO,FE,FC,MO,PR,PC,RA,RE,RN)
# - Visualizzare il contenuto della lista
# - Visualizzare le prime 4 province
# - Visualizzare le ultime 3
# - Assegnare alla lista *emilia* le sigle delle province di Piacenza, Parma, Reggio Emilia, Modena, Ferrara e Bologna recuperandole mediante indice dalla lista province e visualizzare la lista
# - Aggiungere alla lista emilia in coda la privincia XX e visualizzare la lista

# In[ ]:


province = ['BO','FE','FC','MO','PR','PC','RA','RE','RN']
print(province)
#print(province[:4])
#print(province[6:])
emilia = province[:2] + province[3:6] + province[7:8] 
print(emilia)
emilia.append('XX')
print(emilia)
emilia[0] = 'Bologna'
print(emilia)
for k in emilia:
    print('provincia: ',k)


# ### esercizio
# - Inserire in una lista le temperature misurate giornalmente nel mese di gennaio in una città (le temperature sono generate casualmente con valori interi nell'intervallo chiuso -15, 12) 
# - Facoltativo: le temperature hanno valori decimali (1 cifra dopo la virgola)
# - Visualizzare la temperatura massima e la temperatura minima
# - Visualizzare la temperatura media
# - Visualizzare il numero di giorni in cui la temperatura è stata inferiore alla media
# - Visualizzare i giorni (numero del giorno) in cui la temperatura è stata superiore alla media
# - Supponendo che il primo gennaio sia sabato visualizzare il giorno della settimana in cui si è verificata la temperatura massima (nel caso di più giorni con temperatura massima visualizzarli tutti)

# In[ ]:


def maxmin(l: list):
    '''
    visualizza massimo e minimo della lista l
        Parameters:
            l (list) lista di valori
    '''
    max = min = l[0]    # il primo elemento è sia massimo che minimo
    for e in l:         # per ogni elemento della lista
        if e > max:
            max = e
        elif e < min:
            min = e
    print(max,min)

def media(l: list) -> float:
    '''
    restituisce il valore medio della lista l
        Parameters:
            l (list) lista di valori numerici
    '''
    s = 0    # somma valori
    for e in l:
        s += e
    return s / len(l)

def contamin(l: list, v: float) -> int:
    '''
    numero di elementi di l con valore minore di v
    Parameters:
        l (list) lista di valori 
        v (float) valore limite
    Returns:
        n (int) numero di elementi di l minori di v
    '''
    n = 0
    for e in l:
        if e < v:
            n += 1
    return n

def stampasup(l: list, v: float):
    '''
    visualizza l'indice degli elementi di l con valore maggiore di v
    Parameters:
        l (list) lista di valori 
        v (float) valore limite
    '''
    for i in range(len(l)):
        if l[i] > v:
            print(i,end=' ')
    print()

def stampa_giorno_max(l: list):
    '''
    stampa il giorno della settimana ...
    '''
    print('giorno con temperatura massima')
    m = max(l)    # valore massimo della lista
    gs = ['sa','do','lu','ma','me','gi','ve']
    for i in range(len(l)):
        if l[i] == m:      # giorno con temperatura massima
            print(i,gs[i % 7])    
    
from random import randint
temp = []         # lista per il momento vuota
for g in range(31):       # g assume tutti i valori da 0 a 30
    t = randint(-15,12)   # temperatura del giorno g
    temp.append(t)
print(temp)

maxmin(temp)              # visualizza massimo e minimo
med = media(temp)         # temperatura media
print('temperatura media',med)
ngmin = contamin(temp,med)   # numero di giorni con valore inferiore a media
print(ngmin)
stampasup(temp,med)          # visualizza i giorni con temperatura superiore alla media

stampa_giorno_max(temp)      # visualizza il giorno della settimana con temperatura massima


# ### esercizio
# riempire una lista con i valori di sin(x) 360 elementi, indice x tra 0 e 359
# poi, ciclicamente...
# - chiedere un angolo all'utente
# - visualizzare il corrispondente valore precalcolato del seno
# 
# <i>nota
# math.sin opera su radianti
# calcolare math.sin(x * math.pi / 180), anzichè math.sin(x)</i>

# In[ ]:


import math
ls = [0] * 360                      # lista con valori calcolati di sin(x)
for a in range(0,360):
    ls[a] = math.sin(a * math.pi / 180)
    
angolo = int(input('angolo [-1 per terminare]: '))
while angolo != -1:
    print('sin(',angolo,') = ',ls[angolo])
    angolo = int(input('angolo [-1 per terminare]: '))


# ### esercizio
# simulare n lanci di una coppia di dadi
# - n scelto dall'utente
# - contare quante volte si presenta ciascun risultato
# - risultati possibili: da 2 a 12 (somma dei due dadi)
# - per conteggiare i vari risultati, usare una lista di (almeno) 11 valori

# In[ ]:


from random import randint

v = [0] * 13             # quanti risultati da 0 a 12
n = int(input('numero di lanci: '))

for i in range(n):
    l1 = randint(1,6)    # primo dado
    l2 = randint(1,6)    # secondo dado
    ris = l1 + l2        # risultato della coppia di lanci
    print('lancio',i,'risultato',ris)
    v[ris] += 1          # il risultato è uscita una volta in più

for r in range(2,13):
    print('il risultato',r,'è uscito',v[r],'volte')
    


# ### esercizio
# Scrivere le funzioni <b>stampaPrimi</b> che riceve come parametro una lista di interi e stampa tutti i numeri primi presenti nella lista e <b>contaPrimi</b> che riceve come parametro una lista di interi e restituisce il numero di valori primi presenti.<br>
# Stampare e contare i numeri primi presenti in una lista di interi compresi fra 2 e 1000

# In[ ]:


def primo(n: int) -> bool:
    ''' True se n è primo '''
    for d in range(2, n//2 + 1):
        if n % d == 0:
            return False
    return True

def stampaPrimi(l: list):
    ''' visualizza i numeri primi presenti in l'''
    for n in l:
        if primo(n):
            print(n)
            
def conta_primi(l: list) -> int:
    ''' restituisce il numero di numeri primi presenti in l'''
    c = 0     # contatore
    for n in l:
        if primo(n):
            c += 1
    return c
  
lista_numeri = [2,4,7,14,27,13,37,7]    
print('numeri primi in',lista_numeri)    
stampaPrimi(lista_numeri)
print('i numeri primi sono',conta_primi(lista_numeri))


# ## Stringhe

# ### esercizio
# Scrivere la funzione contaCaratteriNumerici che riceve come parametro una stringa e restituisce il numero di caratteri numerici (0-9) presenti in questa. 
# 
# Testare la funzione con varie stringhe. Es. se la stringa è ‘alfa01beta56gamma3’ la funzione restituisce 5, se la stringa è ‘Artificial Intelligence’ la funzione restituisce 0

# In[ ]:


def contaCaratteriNumerici(s: str) -> int:
    ''' return n.ro di caratteri numerici presenti in s'''
    n = 0             # numero caratteri numerici
    for c in s:
        if c in '0123456789':
            n += 1
    return n

print(contaCaratteriNumerici('alfa01beta56gamma3'))
print(contaCaratteriNumerici('Artificial Intelligence'))

