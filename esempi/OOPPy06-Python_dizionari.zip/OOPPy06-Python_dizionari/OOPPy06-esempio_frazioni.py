#!/usr/bin/env python
# coding: utf-8

# > *Alberto Ferrari* - [github](https://albertoferrari.github.io/)

# ## Gestione Frazioni

# #### funzione mcd per semplificazione

# In[ ]:


def mcd(x: int, y: int) -> int:
    '''
    massimo comun divisore 
        Parameters:
            x (int) y (int) interi postitivi
        Returns:
            (int) massimo comun divisore fra x e y
    '''
    d = min(x,y)    # valore minore fra x e y
    while x%d != 0 or y%d != 0:
        d -= 1
    return d


# #### numeri interi

# In[ ]:


def somma_num(n1: int, d1: int, n2:int, d2: int) -> int:
    '''
    restituisce il numeratore della somma di due frazioni
        Parameters:
            n1 (int) d1(int) numeratore e denominatore della prima frazione
            n2 (int) d2(int) numeratore e denominatore della seconda frazione
        Returns: 
            (int) numeratore della somma n1/d1 + n2/d2
    '''
    n = n1*d2 + n2*d1   # numeratore frazione somma
    d = d1 * d2         # denominatore frazione somma
    m = mcd(n,d)        # mcd per semplificazione
    n = n // m          # numeratore semplificato
    d = d // m          # denominatore semplificato
    return n

def somma_den(n1: int, d1: int, n2:int, d2: int) -> int:
    '''
    restituisce il denominatore della somma di due frazioni
        Parameters:
            n1 (int) d1(int) numeratore e denominatore della prima frazione
            n2 (int) d2(int) numeratore e denominatore della seconda frazione
        Returns: 
            (int) denominatore della somma n1/d1 + n2/d2            
    '''
    n = n1*d2 + n2*d1   # numeratore frazione somma
    d = d1 * d2         # denominatore frazione somma
    m = mcd(n,d)        # mcd per semplificazione
    n = n // m          # numeratore semplificato
    d = d // m          # denominatore semplificato
    return d

def main():
    print(somma_num(3,4,1,2))
    print(somma_den(3,4,1,2))
    
main()


# #### liste

# In[ ]:


def somma(f1: list, f2: list) -> list:
    '''
    restituisce la somma di due frazioni
        Parameters:
            f1 (list) prima frazione [numeratore, denominatore]
            f2 (list) seconda frazione [numeratore, denominatore]
        Returns: 
            (list) [numeratore, denominatore] di f1+f2
    '''
    n = f1[0]*f2[1] + f2[0]*f1[1]   # numeratore frazione somma
    d = f1[1] * f2[1]               # denominatore frazione somma
    m = mcd(n,d)        # mcd per semplificazione
    n = n // m          # numeratore semplificato
    d = d // m          # denominatore semplificato
    return [n,d]

def stampa_frazione(f: list):
    '''
    stampare la frazione f
        Parameters:
            f (list) frazione [numeratore, denominatore] lista di 2 elementi interi
    '''
    print('('+str(f[0])+'/'+str(f[1])+')')

def main():
    stampa_frazione(somma([3,4],[1,2]))
    
main()


# #### dizionari

# In[ ]:


def somma(f1: dict, f2: dict) -> dict:
    '''
    restituisce la somma di due frazioni
        Parameters:
            f1 (dict) prima frazione {'num': n, 'den': d}
            f2 (dict) seconda frazione {'num': n, 'den': d}
        Returns: 
            (dict) {num: n, den: d} di f1+f2
    '''
    n = f1['num']*f2['den'] + f2['num']*f1['den']   # numeratore frazione somma
    d = f1['den'] * f2['den']               # denominatore frazione somma
    m = mcd(n,d)        # mcd per semplificazione
    n = n // m          # numeratore semplificato
    d = d // m          # denominatore semplificato
    return {'num': n, 'den': d}

def main():
    print(somma({'num': 3, 'den': 4},{'num': 1, 'den': 2}))
main()


# #### oop

# In[ ]:


class Frazione:
    pass


# In[ ]:


class Frazione:

    def __init__(self, num: int, den: int):
        self._num = num
        if den == 0:
            self._den = 1
        else:
            self._den = den

    def aggiungi(self, f: Frazione):
        n = self._num*f._den + f._num*self._den   # numeratore frazione somma
        d = self._den * f._den               # denominatore frazione somma
        m = mcd(n,d)        # mcd per semplificazione
        self._ = n // m          # numeratore semplificato
        self._den = d // m          # denominatore semplificato    
    
    def stampa(self):
        print(str(self._num)+'/'+str(self._den))
        


# In[ ]:


def main():
    f1 = Frazione(3,4)
    f2 = Frazione(1,2)
    f1.aggiungi(f2)
    f1.stampa()
    
main()


# In[ ]:


class Frazione:
    pass


# In[ ]:


class Frazione:
    '''
    classe che rappresenta una frazione
        Attributes:
            _num (int) numeratore
            _den (int) denominatore
        Methods:
            ...
    '''
    def __init__(self, num: int, den: int):
        self._num = num         # attributo num della frazione
        if den == 0:            # non accetto denominatore = 0 -> 1
            self._den = 1
        else:
            self._den = den

    def mcd(self,x: int, y: int) -> int:
        '''
        massimo comun divisore 
            Parameters:
                x (int) y (int) interi postitivi
            Returns:
                (int) massimo comun divisore fra x e y
        '''
        d = min(x,y)    # valore minore fra x e y
        while x%d != 0 or y%d != 0:
            d -= 1
        return d            
            
    def aggiungi(self, f: Frazione):
        '''
        aggiunge alla frazione il valore della frazione f
        Parameters:
            f (Frazione) frazione da aggiungere
        '''
        n = self._num*f._den + f._num*self._den   # numeratore frazione somma
        d = self._den * f._den               # denominatore frazione somma
        m = self.mcd(n,d)        # mcd per semplificazione
        self._num = n // m          # numeratore semplificato
        self._den = d // m          # denominatore semplificato    
        
    @classmethod
    def somma(cls, f1: Frazione, f2: Frazione) -> Frazione:
        n = f1._num*f2._den + f2._num*f1._den   # numeratore frazione somma
        d = f1._den * f2._den               # denominatore frazione somma
        m = self.mcd(n,d)        # mcd per semplificazione
        n = n // m          # numeratore semplificato
        d = d // m          # denominatore semplificato 
        return Frazione(n,d)
        
    def stampa(self):
        print(str(self._num)+'/'+str(self._den))
        
    def __str__(self):
        return str(self._num)+'/'+str(self._den)
    
    def __add__(self, f: Frazione) -> Frazione:
        n = self._num*f._den + f._num*self._den   # numeratore frazione somma
        d = self._den * f._den               # denominatore frazione somma
        m = self.mcd(n,d)        # mcd per semplificazione
        n = n // m          # numeratore semplificato
        d = d // m          # denominatore semplificato 
        return Frazione(n,d)        


# In[ ]:


def main():
    f1 = Frazione(3,4)
    f2 = Frazione(1,2)
    f3 = f1 + f2
    print(f3)
    f = Frazione(5,0)
    print(f)
    print(type(f1))
    
main()


# In[ ]:


help(Frazione.aggiungi)

