#!/usr/bin/env python
# coding: utf-8

# > *Alberto Ferrari* - [github](https://albertoferrari.github.io/)

# ## enumerate

# In[ ]:


colori = ["rosso", "verde", "giallo", "nero"]
for colore in enumerate(colori):
    print(colore,end=" ")


# In[ ]:


# conversione in lista
lista_colori=list(enumerate(colori))
print(lista_colori)


# In[ ]:


for i, val in enumerate(colori):
    print(i, val)


# ## zip

# In[ ]:


# accoppia gli elementi di due sequenze
ingredienti = ["farina manitoba", "farina", "acqua", "olio", "sale", "lievito"]
quantità = ["200 g", "300 g", "300 ml"]
print(list(zip(ingredienti,quantità)))


# In[ ]:


from math import sqrt
valori = [0, 1, 2, 3, 4]
print(list(map(sqrt, valori)))
print(list(map(bin,range(8))))


# ### operare su liste

# In[ ]:


ingredienti = ["farina", "acqua", "olio", "sale", "lievito"]
print(ingredienti)  #['farina', 'acqua', 'olio', 'sale', 'lievito']

ingredienti.reverse()       # in place
print(ingredienti)  #['lievito', 'sale', 'olio', 'acqua', 'farina']

ingredienti.sort()          # in place
print(ingredienti)  #['acqua', 'farina', 'lievito', 'olio', 'sale']

ingredienti = ["farina", "acqua", "olio", "sale", "lievito"]
ingr_rev = sorted(ingredienti,reverse=True) # not in place
print(ingredienti)  #['farina', 'acqua', 'olio', 'sale', 'lievito']
print(ingr_rev)     #['sale', 'olio', 'lievito', 'farina', 'acqua']
ingr_lun = sorted(ingredienti, key=len)
print(ingr_lun)     #['olio', 'sale', 'acqua', 'farina', 'lievito']


# ## dizionari

# In[ ]:


#definizione di dizionario {}
tel = {"john": 4098, "terry": 4139}
#accesso a un elemento
print(tel["john"])  #4098
#ggiunta di una coppia chiave/valore
tel["graham"] = 4127
#visualizzazione dizionario
print(tel)          #{"graham": 4127, "terry": 4139, "john": 4098}
#visualizzazione chiavi
print(list(tel))    #['john', 'terry', 'graham']
#lista di coppie
print(list(tel.items())) 
#[('john', 4098), ('terry', 4139), ('graham', 4127)]
#sequenza di elementi
for k in tel.keys():
    print(k,tel[k])


# ## matrici

# In[ ]:


matrix = [[2, 4, 3, 8],
          [9, 3, 2, 7],
          [5, 6, 9, 1]]
rows = len(matrix)
cols = len(matrix[0])

for x in range(cols):
    total = 0
    for y in range(rows):
        val = matrix[y][x]
        total += val
    print("Col #", x, "sums to", total)


# ### inizializzazione matrice

# In[ ]:


cols = 3    #dato noto
rows = 4    #dato noto
#inizializzazione di tutti gli elementi a ' '
matrix = [[' ' for x in range(cols)] for y in range(rows)]
print(matrix)


# In[ ]:


#metodo alternativo
matrix = []
for y in range(rows):
    new_row = []
    for x in range(cols):
        new_row.append(' ')
    matrix.append(new_row)
print(matrix)

