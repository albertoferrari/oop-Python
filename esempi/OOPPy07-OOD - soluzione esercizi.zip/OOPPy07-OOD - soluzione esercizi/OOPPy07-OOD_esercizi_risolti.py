#!/usr/bin/env python
# coding: utf-8

# > *Alberto Ferrari* - [github](https://albertoferrari.github.io/)

# ## Object Oriented Design - esercizi

# ### esercizio
# SIM e telefonate
# 
# Si vogliono gestire le informazioni relative alle schede SIM e alle telefonate effettuate da queste schede. 
# 
# Per ogni SIM interessa il numero di telefono, il credito disponibile che non può mai essere negativo e la lista delle telefonate effettuate. 
# 
# Per ogni telefonata interessa il numero chiamato e la durata in secondi. 
# 
# La classe Sim dovrà fornire le seguenti funzionalità:
# - Un costruttore parametrizzato che crea una SIM con il relativo numero di telefono e il credito disponibile (se non fornito il credito di default è di 10 euro)
# - Un metodo per l’inserimento di una telefonata
# - Un metodo per il calcolo della durata complessiva delle telefonate effettuate (restituisce una stringa nella forma hh:mm:ss
# - Un metodo che restituisce una stringa con tutti i dati relativi alla SIM e alle telefonate effettuate.
# 
# Definire il diagramma delle classi Telefonata e Sim
# 
# Implementare le classi in Python
# 
# Testare le classi istanziando oggetti e chiamando tutti i metodi

# ### class diagram
# ![telefonate class diagram](sim.jpg)

# In[ ]:


class Telefonata:
    '''
    classe che rappresenta una telefonata
        Attributes:
            numero (str) numero chiamato
            durata (int) durata in secondi
        Methods:
            ...
    '''
    def __init__(self,numero: str,durata: int):
        self._numero = numero
        self._durata = max(durata, 0)
        
    def get_durata(self):
        return self._durata
    
    def __str__(self):
        return "numero chiamato "+self._numero+" durata "+str(self._durata)+" secondi"


# In[ ]:


t1 = Telefonata('0521 226500', 45)
t2 = Telefonata('113',-5)
t3 = Telefonata('+39 0521 902111', 125)
print(t1)
print(t2)
print(t3)


# In[ ]:


class Sim:
    '''
    classe che rappresenta una SIM telefonica
        Attributes:
            numero (str) numero di telefono associato alla SIM
            credito (float) credito in euro
            lista_telefonate (list) lista telefonate effettuate
        Methods:
            ...
    '''
    def __init__(self, numero = "113", credito = 10):
        self._numero = numero
        self._credito = max(credito,0)
        self._lista_telefonate = []
        
    def inserisci_telefonata(self, t: Telefonata):
        self._lista_telefonate.append(t)
        
    def durata_telefonate(self) -> str:
        '''
        durata delle telefonate in ore minuti e secondi
        '''
        durata = 0
        for t in self._lista_telefonate:
            durata += t.get_durata()
        s = durata % 60
        m = (durata // 60) % 60
        h = durata // 3600
        if h < 10:
            dt = '0'+str(h)
        else:
            dt = str(h)
        if m < 10:
            dt += ':0' + str(m)
        else:
            dt += ':' + str(m)
        if s < 10:
            dt += ':0' + str(s)
        else:
            dt += ':' + str(s)
        return dt
    
    def __str__(self):
        s = 'SIM associata al numero '+self._numero
        s += ' credito '+str(self._credito)+' Euro'
        s += ' telefonate effettuate:'
        for t in self._lista_telefonate:
            s += '\n'+str(t)
        return s


# In[ ]:


t1 = Telefonata('0521 226500', 45)
t2 = Telefonata('113',-5)
t3 = Telefonata('+39 0521 902111', 125)
sim1 = Sim('333 445566', 100)
sim1.inserisci_telefonata(t1)
sim1.inserisci_telefonata(t2)
sim1.inserisci_telefonata(t3)
print(sim1)
print('durata telefonate',sim1.durata_telefonate())

