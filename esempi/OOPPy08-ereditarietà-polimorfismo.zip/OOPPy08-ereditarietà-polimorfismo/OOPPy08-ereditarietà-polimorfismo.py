#!/usr/bin/env python
# coding: utf-8

# > *Alberto Ferrari* - [github](https://albertoferrari.github.io/)

# ### Ereditarietà

# ### classe base - PoligonoRegolare

# In[ ]:


class PoligonoRegolare:
    '''
    Poligono regolare
        Attributes:
            lato (float) misura del lato
            nLati (int) numero di lati
    '''
    def __init__(self, lato: float, nLati: int):
        self._lato = lato
        self._nLati = nLati
        
    def set_lato(self,l: float):
        if l > 0:
            self._lato = l

    def perimetro(self):
        '''
        perimetro del poligono
        '''
        return self._lato * self._nLati

    def area(self):
        raise Exception("Non è possibile calcolare l'area")
        
    def stampa(self):
        print('Poligono regolare con',self._nLati,'lati di lunghezza',self._lato)


# In[ ]:


p = PoligonoRegolare(2.75,8)
p.stampa()
print('perimetro',p.perimetro())
# print('area',p.area())


# ### classe derivata - TiangoloEquilatero

# In[ ]:


class TriangoloEquilatero(PoligonoRegolare):
    '''
    il triangolo equilatero è un poligono regolare con 3 lati
    '''
    def __init__(self, lato: float):
        super().__init__(lato,3)

    def area(self):
        area = (3**0.5)/4*(self._lato**2)
        return area
        
    def stampa(self):
        print('Triangolo equilatero con lato',self._lato)


# In[ ]:


t = TriangoloEquilatero(12.8)
t.stampa()
print('area',t.area())
print('perimetro',t.perimetro())


# ### classe derivata - Quadrato

# In[ ]:


class Quadrato(PoligonoRegolare):
    '''
    il quadrato è un poligono regolare con quattro lati
    '''
    def __init__(self, lato: float):
        super().__init__(lato,4)

    def area(self):
        area = self._lato**2
        return area
    
    def stampa(self):
        print('Quadrato con lato',self._lato)    


# In[ ]:


q = Quadrato(5.6)
print('area',q.area())
print('perimetro',q.perimetro())
q.stampa()


# #### oggetti delle varie classi

# In[ ]:


p = PoligonoRegolare(10,6)       # poligono regolare con 6 lati
p.stampa()
print('perimetro',p.perimetro())
# print('area',p.area())           # Exception: Non è possibile calcolare l'area


# In[ ]:


t = TriangoloEquilatero(20)
t.stampa()
print('perimetro',t.perimetro())
print('area',t.area()) 


# In[ ]:


q = Quadrato(30)
q.stampa()
print('perimetro',q.perimetro())
print('area',q.area()) 


# ### verifica se un oggetto è istanza di una classe

# In[ ]:


p = PoligonoRegolare(10,6)       # poligono regolare con 6 lati
t = TriangoloEquilatero(20)
q = Quadrato(30)
print(isinstance(p,PoligonoRegolare))
print(isinstance(p,TriangoloEquilatero))
print(isinstance(p,Quadrato))


# In[ ]:


print(isinstance(t,PoligonoRegolare))
print(isinstance(t,TriangoloEquilatero))
print(isinstance(t,Quadrato))


# In[ ]:


print(isinstance(q,PoligonoRegolare))
print(isinstance(q,TriangoloEquilatero))
print(isinstance(q,Quadrato))


# #### sottoclasse - superclasse

# In[ ]:


print(issubclass(TriangoloEquilatero,PoligonoRegolare))
print(issubclass(Quadrato,PoligonoRegolare))
print(issubclass(TriangoloEquilatero,Quadrato))


# ### esercizio
# aggiungere il metodo set_lato(self, lato: int) che modifica la lunghezza del lato alla classe PoligonoRegolare
# - è possibile modificare la lunghezza del lato di un TriangoloEquilatero?

# In[ ]:


t2 = TriangoloEquilatero(6.78)
t2.stampa()
t2.set_lato(-1000)
t2.stampa()


# ### gerarchia di classi

# In[ ]:


class QuadratoColorato(Quadrato):
    '''
    quadrato con un colore di riempimento
    '''
    def __init__(self, lato: float, colore: str):
        self._colore = colore
        super().__init__(lato)
    
    def stampa(self):
        super().stampa()
        print('         e colore',self._colore)
        
    def qualeColore(self):
        return self._colore


# In[ ]:


qc = QuadratoColorato(5.9,'rosso')
qc.stampa()
print('perimetro',qc.perimetro())
print('area',qc.area()) 
print(qc.qualeColore())


# In[ ]:


print(isinstance(qc,PoligonoRegolare))
print(isinstance(qc,TriangoloEquilatero))
print(isinstance(qc,Quadrato))
print(isinstance(qc,QuadratoColorato))


# In[ ]:


print(issubclass(QuadratoColorato,PoligonoRegolare))
print(issubclass(QuadratoColorato,Quadrato))


# ## Polimorfismo

# In[ ]:


t = TriangoloEquilatero(10)
q = Quadrato(15)
qc = QuadratoColorato(20,'giallo')
poligoni = [t,q,qc]
for pol in poligoni:
    pol.stampa()
    print('area',pol.area())
    print('----------------')

