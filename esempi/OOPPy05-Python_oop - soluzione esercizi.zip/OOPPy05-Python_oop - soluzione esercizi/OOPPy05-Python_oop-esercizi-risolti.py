#!/usr/bin/env python
# coding: utf-8

# > *Alberto Ferrari* - [github](https://albertoferrari.github.io/)

# ## OOP - Python - esercizi - risolti

# ### esercizio
# definire una classe che modella un'ellisse
# 
# campi privati (parametri del costruttore)
# - semiassi: a, b
# 
# metodi pubblici per ottenere:
# - area: $ \pi⋅a⋅b $
# - distanza focale: $ 2⋅\sqrt{|a^2 - b^2|} $
# 
# Creare poi un oggetto con dati forniti dall'utente visualizzare area e distanza focale dell'ellisse

# In[ ]:


import math

class Ellisse:

    def __init__(self, a: float, b: float):
        self._a = abs(a)
        self._b = abs(b)
       
    def area(self) -> float:
        return math.pi * self._a * self._b
    
    def distanza_focale(self) -> float:
        return 2 * math.sqrt(abs(self._a ** 2 - self._b ** 2))
    
    def __str__(self) -> str:
        return 'ellisse con semiassi ' + str(self._a) + ' e ' + str(self._b)
    
s1 = float(input('primo   semiasse: '))
s2 = float(input('secondo semiasse: '))
e = Ellisse(s1,s2)
print(e)
print('area',e.area())
print('distanza focale',e.distanza_focale())


# In[ ]:


class Ellisse:

    def __init__(self, a: float, b: float):
        self._a = abs(a)
        self._b = abs(b)
        self._area = math.pi * self._a * self._b
       
    def area(self) -> float:
        return math.pi * self._a * self._b
    
    def distanza_focale(self) -> float:
        return 2 * math.sqrt(abs(self._a ** 2 - self._b ** 2))
    
    def __gt__(self, e: 'Ellisse') -> bool:
        '''
        confronta due ellissi
            Parametrs:
                e (Ellisse) ellisse da confrontare
            Returns:
                (bool) True se l'ellisse in esame ha area maggiore di e
        '''
        if self.area() > e.area():
            return True
        else:
            return False


# In[ ]:


e1 = Ellisse(2,5999)
e2 = Ellisse(3,4)
print(e1.area())
print(e2.area())
if e1 > e2:
    print('e1 > e2')
else:
    print('e1 <= e2')


# ### esercizio
# Scrivere la classe Motorino che ha i seguenti attributi
# 
# colore: una stringa indicante il colore del motorino, velocità: un numero intero indicante la velocità in Km/h che possiede il motorino, tipo: una stringa indicante la marca e il modello del motorino es. “Piaggio scarabeo”, antifurto un boolean che indica se è stato inserito l’antifurto (ha un valore iniziale pari a false)
# 
# Il costruttore ha come parametri una stringa per il colore, una stringa per il tipo, un numero per la velocità ed assegna opportunamente i valori dei parametri agli attributi. 
# 
# Scrivere il metodo getVelocità che restituisce la velocità del motorino, scrivere inoltre il metodo accelera che ha come parametro un numero intero indicante i Km/h che si vogliono aggiungere alla velocità, il metodo verifica il valore dell’attributo antifurto se è false aggiunge il valore del parametro all’attributo velocità, altrimenti non fa nulla. Scrivere il metodo switchAntifurto che modifica da True a False o da False a True il valore di antifurto.
# 
# Istanziare un oggetto della classe e testare i vari metodi

# In[ ]:


class Motorino:

    def __init__(self, c: str, t: str, v: int):
        self._colore = c
        self._tipo = t
        self._velocità = v
        self._antifurto = False
       
    def get_velocità(self) -> int:
        return self._velocità
    
    def set_velocità(self, v):
        self._velocità = v
    
    def accelera(self, v: int):
        if self._antifurto:
            return
        self._velocità += v
        
    def switchAntifurto(self):
        self._antifurto = not self._antifurto
        

m = Motorino('rosso','Ducati desmosedici',300)
print(m.get_velocità())
m.switchAntifurto()
m.accelera(30)
print(m.get_velocità())
m.switchAntifurto()
m.accelera(30)
print(m.get_velocità())


# ### esercizio
# Creare la classe Orologio con le seguenti caratteristiche:
# Attributi ore e minuti entrambi di tipo int 
# - non dovranno mai contenere valori negativi e dovranno avere valori compresi fra 0 e 23 per le ore e fra 0 e 59 per i minuti
# - se i valori non sono accettabili l'orologio viene posizionato alle ore 12:00
# 
# Metodo avanza() che fa avanzare l'orologio di 1 minuto (aggiornando eventualmente le ore)
# 
# Metodo to_string() che restituisce una stringa di esattamente 5 caratteri (i primi due per le ore poi il carattere ":" poi due caratteri per i minuti) (Esempio 09:35)
# 
# Istanziare un oggetto della classe e testare i vari metodi

# ![Orologio](Orologio.jpg)

# In[ ]:


class Orologio:
    '''
    classe che implementa un orologio
        Attributes:
            ore (int) ore [0,23]
            minuti (int) minuti [0,59]
        Methods:
            avanza() avanza di un minuto
    '''
    
    def __init__(self, ore: int, minuti: int):
        if 0 <= ore <= 23 and 0 <= minuti <= 59:
            self._ore = ore
            self._minuti = minuti
        else:
            self._ore = 12
            self._minuti = 0
            
    def get_ore(self) -> int:
        return self._ore
    
    def get_minuti(self) -> int:
        return self._minuti
    
    def avanza(self,):
        '''
        avanza di 1 minuto
        '''
        self._minuti = self._minuti + 1
        if self._minuti > 59:
            self._minuti = 0
            self._ore = (self._ore + 1) % 24
    
    def __str__(self) -> str:
        '''
        stringa nel formato hh:mm
        '''
        if self._ore < 10:
            s = '0' + str(self._ore)
        else:
            s = str(self._ore)
        if self._minuti < 10:
            s += ':0' + str(self._minuti)
        else:
            s += ':' + str(self._minuti)
        return s


# In[ ]:


o1 = Orologio(23,58)
print(o1)
o1.avanza()
print(o1)
print(o1.get_ore())
print(o1.get_minuti())
o1.avanza()
print(o1)


# In[ ]:


from orario import Orologio


# ### esercizio
# Aggiungere alla classe Orologio il metodo differenza che ha come parametro un Orologio e restituisce i minuti di differenza fra l'orologio su cui è chiamato il metodo e quello passato come parametro (la differenza può anche essere negativa)
# 
# Testare il metododo istanziando due oggetti

# In[ ]:


class Orologio:
    
    def __init__(self, ore: int, minuti: int):
        self._ore = 12
        self._minuti = 0
        if 0 <= ore <= 23:
            self._ore = ore
        if 0 <= minuti <= 59:
            self._minuti = minuti
    
    def avanza(self):
        self._minuti += 1
        if self._minuti > 59:
            self._minuti = 0
            self._ore = self._ore + 1
    
    def __str__(self) -> str:
        if self._ore < 10:
            s = '0' + str(self._ore)
        else:
            s = str(self._ore)
        if self._minuti < 10:
            s += ':0' + str(self._minuti)
        else:
            s += ':' + str(self._minuti)
        return s
    
    def differenza(self, o: Orologio) -> int:
        d = (self._ore * 60 + self._minuti) - (o._ore * 60 + o._minuti)
        return d
    
o1 = Orologio(13,10)
o2 = Orologio(15,5)
print(o1.differenza(o2))
print(o2.differenza(o1))


# Realizzare la classe Rettangolo con opportuni attributi, costruttore e metodi in modo da poter gestire rettangoli e calcolare area, perimetro, diagonale, visualizzare gli attributi (__str__) e conoscere se un rettangolo è in realtà un quadrato.
# 
# Facoltativo definire i metodi (dunder methods) che permettono di confrontare rettangoli in base alla loro area.

# In[ ]:


import math

class Rettangolo:
    
    def __init__(self, base, altezza):
        self._base = abs(base)
        self._altezza = abs(altezza)
        
    def area(self):
        return self._base * self._altezza

    def perimetro(self):
        return (self._base + self._altezza) * 2
    
    def diagonale(self):
        return math.sqrt(self._base ** 2 + self._altezza ** 2)
    
    def __str__(self):
        return 'rettangolo con base ' + str(self._base) + ' e altezza ' + str(self._altezza)
    
    def isQuadrato(self):
        return self._base == self._altezza
    
    def __gt__(self,r):
        return self.area() > r.area()
    
r = Rettangolo(40,40)
print(r)
print('area =',r.area())
print('perimetro =',r.perimetro())
print('diagonale =',r.diagonale())
if r.isQuadrato():
    print(r,'è un quadrato')
else:
    print(r,'non è un quadrato')
r2 = Rettangolo(50,30)
if r > r2:
    print(r,' > ',r2)
else:
    print(r,' <= ',r2)

