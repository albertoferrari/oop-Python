#!/usr/bin/env python
# coding: utf-8

# > *Alberto Ferrari* - [github](https://albertoferrari.github.io/)

# ## OOP - Python - esercizi - risolti

# ### esercizio
# definire una classe che modella un'ellisse
# 
# campi privati (parametri del costruttore)
# - semiassi: a, b
# 
# metodi pubblici per ottenere:
# - area: $ \pi⋅a⋅b $
# - distanza focale: $ 2⋅\sqrt{|a^2 - b^2|} $
# 
# Creare poi un oggetto con dati forniti dall'utente visualizzare area e distanza focale dell'ellisse

# In[ ]:


import math

class Ellisse:

    def __init__(self, a: float, b: float):
        self._a = abs(a)
        self._b = abs(b)
       
    def area(self) -> float:
        return math.pi * self._a * self._b
    
    def distanza_focale(self) -> float:
        return 2 * math.sqrt(abs(self._a ** 2 - self._b ** 2))
    
    def __str__(self) -> str:
        return 'ellisse con semiassi ' + str(self._a) + ' e ' + str(self._b)
    
s1 = float(input('primo   semiasse: '))
s2 = float(input('secondo semiasse: '))
e = Ellisse(s1,s2)
print(e)
print('area',e.area())
print('distanza focale',e.distanza_focale())
e._a = 1000
print('area',e.area())


# In[ ]:


class Ellisse:

    def __init__(self, a: float, b: float):
        self._a = abs(a)
        self._b = abs(b)
        self._area = math.pi * self._a * self._b
       
    def area(self) -> float:
        return math.pi * self._a * self._b
    
    def distanza_focale(self) -> float:
        return 2 * math.sqrt(abs(self._a ** 2 - self._b ** 2))
    
    def __gt__(self, e: 'Ellisse') -> bool:
        '''
        confronta due ellissi
            Parametrs:
                e (Ellisse) ellisse da confrontare
            Returns:
                (bool) True se l'ellisse in esame ha area maggiore di e
        '''
        if self.area() > e.area():
            return True
        else:
            return False


# In[ ]:


e1 = Ellisse(2,5999)
e2 = Ellisse(3,4)
print(e1.area())
print(e2.area())
if e1 > e2:
    print('e1 > e2')
else:
    print('e1 <= e2')


# ### esercizio
# Scrivere la classe Motorino che ha i seguenti attributi
# 
# colore: una stringa indicante il colore del motorino, velocità: un numero intero indicante la velocità in Km/h che possiede il motorino, tipo: una stringa indicante la marca e il modello del motorino es. “Piaggio scarabeo”, antifurto un boolean che indica se è stato inserito l’antifurto (ha un valore iniziale pari a false)
# 
# Il costruttore ha come parametri una stringa per il colore, una stringa per il tipo, un numero per la velocità ed assegna opportunamente i valori dei parametri agli attributi. 
# 
# Scrivere il metodo getVelocità che restituisce la velocità del motorino, scrivere inoltre il metodo accelera che ha come parametro un numero intero indicante i Km/h che si vogliono aggiungere alla velocità, il metodo verifica il valore dell’attributo antifurto se è false aggiunge il valore del parametro all’attributo velocità, altrimenti non fa nulla. Scrivere il metodo switchAntifurto che modifica da True a False o da False a True il valore di antifurto.
# 
# Istanziare un oggetto della classe e testare i vari metodi

# In[ ]:


class Motorino:

    def __init__(self, c: str, t: str, v: int):
        self._colore = c
        self._tipo = t
        self._velocità = v
        self._antifurto = False
       
    def get_velocità(self) -> int:
        return self._velocità
    
    def set_velocità(self, v):
        self._velocità = v
    
    def accelera(self, v: int):
        if self._antifurto:
            return
        self._velocità += v
        
    def switchAntifurto(self):
        self._antifurto = not self._antifurto
        

m = Motorino('rosso','Ducati desmosedici',300)
print(m.get_velocità())
m.switchAntifurto()
m.accelera(30)
print(m.get_velocità())
m.switchAntifurto()
m.accelera(30)
print(m.get_velocità())


# ### esercizio
# Creare la classe Orologio con le seguenti caratteristiche:
# Attributi ore e minuti entrambi di tipo int 
# - non dovranno mai contenere valori negativi e dovranno avere valori compresi fra 0 e 23 per le ore e fra 0 e 59 per i minuti
# - se i valori non sono accettabili l'orologio viene posizionato alle ore 12:00
# 
# Metodo avanza() che fa avanzare l'orologio di 1 minuto (aggiornando eventualmente le ore)
# 
# Metodo to_string() che restituisce una stringa di esattamente 5 caratteri (i primi due per le ore poi il carattere ":" poi due caratteri per i minuti) (Esempio 09:35)
# 
# Istanziare un oggetto della classe e testare i vari metodi

# ![Orologio](Orologio.jpg)

# In[ ]:


class Orologio:
    '''
    classe che implementa un orologio
        Attributes:
            ore (int) ore [0,23]
            minuti (int) minuti [0,59]
        Methods:
            avanza() avanza di un minuto
    '''
    
    def __init__(self, ore: int, minuti: int):
        self._ore = 12
        self._minuti = 0
        if 0 <= ore <= 23:
            self._ore = ore
        if 0 <= minuti <= 59:
            self._minuti = minuti
            
    def get_ore(self) -> int:
        return self._ore
    
    def get_minuti(self) -> int:
        return self._minuti
    
    def avanza(self, n: int):
        '''
        avanza di n minuti
        '''
        self._minuti = (self._minuti + n) % 60
        if self._minuti > 59:
            self._minuti = 0
            self._ore = (self._ore + 1) % 24
    
    def __str__(self) -> str:
        '''
        stringa nel formato hh:mm
        '''
        if self._ore < 10:
            s = '0' + str(self._ore)
        else:
            s = str(self._ore)
        if self._minuti < 10:
            s += ':0' + str(self._minuti)
        else:
            s += ':' + str(self._minuti)
        return s


# In[ ]:


o1 = Orologio(23,58)
print(o1)
o1.avanza()
print(o1)
print(o1.get_ore())
print(o1.get_minuti())
o1.avanza()
print(o1)


# In[ ]:


from orario import Orologio


# ### esercizio
# Aggiungere alla classe Orologio il metodo differenza che ha come parametro un Orologio e restituisce i minuti di differenza fra l'orologio su cui è chiamato il metodo e quello passato come parametro (la differenza può anche essere negativa)
# 
# Testare il metododo istanziando due oggetti

# In[ ]:


class Orologio:
    
    def __init__(self, ore: int, minuti: int):
        self._ore = 12
        self._minuti = 0
        if 0 <= ore <= 23:
            self._ore = ore
        if 0 <= minuti <= 59:
            self._minuti = minuti
    
    def avanza(self):
        self._minuti += 1
        if self._minuti > 59:
            self._minuti = 0
            self._ore = self._ore + 1
    
    def to_string(self) -> str:
        if self._ore < 10:
            s = '0' + str(self._ore)
        else:
            s = str(self._ore)
        if self._minuti < 10:
            s += ':0' + str(self._minuti)
        else:
            s += ':' + str(self._minuti)
        return s
    
    def differenza(self, o: Orologio) -> int:
        d = (self._ore * 60 + self._minuti) - (o._ore * 60 + o._minuti)
        return d


# In[ ]:


o1 = Orologio(13,10)
o2 = Orologio(15,5)
print(o1.differenza(o2))
print(o2.differenza(o1))


# ### esercizio
# 
# Si vuole realizzare una classe per operare con frazioni numeriche. 
# 
# La classe Frazione ha due attributi privati interi num e den (il denominatore di una frazione non deve mai avere come valore 0 (*in questo caso comunicare in output “denominatore errato” e porre il denominatore a 1*).
# 
# Il costruttore della classe frazione riceve come parametri il numeratore e il denominatore:
# - esempio: Frazione(3,4) crea una frazione il cui valore è ¾
# 
# Una volta creata una frazione è possibile ottenere il valore del numeratore e del denominatore con opportuni metodi ed è possibile anche modificarne il valore rispettando i vincoli.
# 
# Deve essere presente il metodo __str__() che restituisce una rappresentazione della frazione nel formato (numeratore / denominatore) nel caso di frazione con valore ¾ restituisce la stringa (3/4).
# 
# La frazione deve però sempre essere rappresentata ai minimi termini sia dal metodo __str__() sia dei metodi che permettono di ottenere il valore degli attributi.
# - Frazione(4,8) ha in realtà il valore ½ 
# 
# Deve inoltre essere presente un metodo che restituisce il valore della frazione (nel caso di frazione con numeratore 5 e denominatore 4 restituisce 1.25).
# 
# Il metodo *moltiplica* riceve come parametro un valore intero e moltiplica la frazione per quel valore, analogamente si comporta il metodo *somma*.
# 
# Due ulteriori metodi permettono, il primo di sottrarre e il secondo di dividere, da una frazione un’altra frazione ricevuta come parametro.
# 
# Creare poi un programma (main.py) che istanzia la frazione fa passando come parametri i valori 3 e 6 poi istanzia la frazione fb passando come parametri -3 e 2, visualizza la rappresentazione delle due frazioni poi moltiplica la prima frazione per 2 mentre sottrae alla seconda la frazione ¾, visualizza poi le due frazioni dopo le operazioni effettuate.

# https://www.mathepower.com/it/sommafrazioni.php
# 
# https://www.mathepower.com/it/moltiplicazionefrazioni.php

# In[ ]:


import math

class Frazione:
    
    def __init__(self, n: int, d: int):
        self._num = n
        if d==0:
            print('denominatore errato')
            self._den = 1
        else:
            self._den = d
        self.riduci()
    
    def get_num(self):
        return self._num    
    
    def get_den(self):
        return self._den

    def set_num(self,n):
        self._num = n
        self.riduci()
    
    def set_den(self,d):
        if d == 0:
            return
        self._den = d
        self.riduci()
    
    def __str__(self) -> str:
        return '('+str(self._num)+'/'+str(self._den)+')'
    
    def valore(self) -> float:
        return self._num / self._den
    
    def moltiplica(self,v: int):
        self._num = self._num * v
        self.riduci()
        
    def somma(self,v: int):
        self._num = self._num + (self._den * v)
        self.riduci()
        
    def sottrai(self,f: 'Frazione'):
        self._num = self._num * f.get_den() - f.get_num() * self._den
        self._den = self._den * f.get_den()
        self.riduci()
    
    def dividi(self,f: 'Frazione'):
        self._num = self._num * f.get_den()
        self._den = self._den * f.get_num()
        self.riduci()
    
    def riduci(self):
        mcd = math.gcd(self._num,self._den)
        self._num = self._num // mcd
        self._den = self._den // mcd
        if (self._den<0):
            self._den = -self._den
            self._num = -self._num


# In[ ]:


fa = Frazione(3,6)
fb = Frazione(-3,2)
print(fa)
print(fb)
fa.moltiplica(2)
print(fa)
fb.sottrai(Frazione(3,4))
print(fb)


# ### esercizio
# Si vuole realizzare una applicazione che gestisca dei brani musicali in formato digitale. 
# Le caratteristiche di ciascun brano musicale sono:  
# - il formato (mp3, wav, etc.)  
# - il titolo 
# - l'autore del brano
# - la durata in secondi
# 
# La classe deve avere un costruttore che inizializza tutti gli attributi.
# 
# Scrivere una classe *Brano* che rappresenti tutte le caratteristiche di un brano musicale digitale. 
# 
# La classe deve inoltre mettere a disposizione le seguenti operazioni:
# - get_autore() che ritorna l'autore del brano
# - get_titolo() che ritorna il titolo di un brano musicale
# - get_formato() che ritorna il formato di un brano musicale
# - set_formato(f) che cambia il formato di un brano musicale
# - set_durata(d) che modifica la durata del brano solo se il parametro d ha valore positivo e minore di 1000
# - aumenta_durata() che incrementa la durata del 10%
# - __str__() che restituisce una stringa del tipo
#  “Autore: aaaa Titolo: tttt Formato: ffff Durata: dddd secondi”
# 
# Istanziare 3 poi i brani b1,b2,b3 e poi testare i vari metodi e infine visualizzare tutte le informazioni dei 3 brani.

# In[ ]:


class Brano:
    
    def __init__(self,formato: str, titolo: str, autore: str, durata: int):
        self._formato = formato
        self._titolo = titolo
        self._autore = autore
        self._durata = durata
        
    def __str__(self) ->str:
        s = 'formato: ' + self._formato
        s += ' - titolo: ' + self._titolo
        s += ' - autore: ' + self._autore
        s += ' - durata: ' + str(self._durata) + ' secondi'
        return s
    
    def get_autore(self):
        return self._autore()
    
    def set_formato(self, f: str):
        self._formato = f
        
    def set_durata(self, d):
        if 0 < d < 1000:
            self._durata = d
            
    def aumenta_durata(self):
        self._durata = self._durata + (self._durata * 10) // 100


# In[ ]:


b1 = Brano('mp3','Like a Rolling Stone','Bob Dylan',230)
b2 = Brano('ogg','Satisfaction','Rolling Stones',200)
b3 = Brano('wma','Imagine','John Lennon',185)
print(b1)
print(b2)
print(b3)
b2.aumenta_durata()
print(b2)

