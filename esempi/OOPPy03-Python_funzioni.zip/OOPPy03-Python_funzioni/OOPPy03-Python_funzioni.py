#!/usr/bin/env python
# coding: utf-8

# > *Alberto Ferrari* - [github](https://albertoferrari.github.io/)

# ## funzioni

# In[ ]:


def cubo(x: float) -> float:
    '''
    calcolo del cubo di un valore
        Parameters:
            x (float) valore di cui vogliamo calcolare il cubo
        Returns:
            (float) cubo di x
    '''
    c = x ** 3   # c variabile locale   
    return c

def main():
    v = float(input('vuoi calcolare il cubo di: '))
    print('il cubo di',v,'è',cubo(v))

main()


# In[ ]:


help(cubo)


# In[ ]:


import random
help(random.randint)
print(random.randint(10,20))


# In[ ]:


def ipotenusa(a: float, b: float) -> float:
    ''' 
    calcolo dell'ipotenusa di un triangolo rettangolo
        Parameters:
            a (float) b(float) misure dei cateti
        Retruns:
            (float) misura dell'ipotenusa
    '''
    c = (a ** 2 + b ** 2) ** 0.5
    return c

c1 = float(input('cateto 1: '))
c2 = float(input('cateto 2: '))
ip = ipotenusa(c1, c2)
print('ipotenusa:', ip)


# ### importanza della docstring

# In[ ]:


# funzione help
help(ipotenusa)


# In[ ]:


# attributo __doc__
print(ipotenusa.__doc__)


# In[ ]:


# informazioni sul modulo math
import math
help(math)


# In[ ]:


help(math.sqrt)


# ## procedure

# In[ ]:


def stampa_tabellina(y: int, n: int):
    '''
    stampa tabellina su unica riga 
        Parametrs:
            y (int) tabellina di y
            n (int) fino a y * n
    '''
    for x in range(1, n + 1):
        val = x * y
        print(f"{val:3}", end=" ")
    print()

def stampa_tavola(n: int):
    '''
    stampa la tavola pitagorica con n righe e n colonne
        Parametrs:
            n (int) numero di righe e colonne della tavola pitagorica    
    '''
    for y in range(1, n + 1):
        stampa_tabellina(y, n)

def main():
    stampa_tavola(5)
    
main()


# ## moduli

# In[ ]:


# importazione modulo math
import math
y = math.sin(math.pi / 4)
print(y)


# In[ ]:


# importazione funzioni e costanti da un modulo
from math import sin, pi
print(sin(pi / 4))


# In[ ]:


# numeri pseudocasuali
from random import randint
dado1 = randint(1, 6)  # simula il lancio di un dado
dado2 = randint(1, 6)  # simula il lancio di un dado
print('primo lancio:',dado1,'secondo lancio',dado2)


# ### esempi

# In[ ]:


# funzione senza parametri
def stampa_saluti():
    ''' 
    visualizza una stringa di 40 caratteri 
    tutta di asterischi con al centro "ciao" 
    '''
    quanti_asterischi = 20 - len('ciao') // 2 - 1      # numero di asterischi da visualizzare prima e dopo 
    ast = '*' * quanti_asterischi
    print(ast,'ciao',ast)
    
stampa_saluti()


# In[ ]:


# funzione con parametri
def stampa_saluti(s: str):
    ''' 
    visualizza una stringa di 40 caratteri 
    tutta di asterischi con al centro la stringa s 
    '''
    quanti_asterischi = 20 - len(s) // 2 - 1      # numero di asterischi da visualizzare prima e dopo 
    ast = '*' * quanti_asterischi
    print(ast,s,ast)
    
stampa_saluti('saluti')


# In[ ]:


# funzione che chiama un'altra funzione
def tanti_saluti(s: str):
    ''' visualizza 5 volte stampa_saluti(s) '''
    n = 1
    while n <= 5:
        stampa_saluti(s)
        n += 1

tanti_saluti('buongiorno')


# In[ ]:


# funzione che restituisce un valore
def minore(a: float, b: float) -> float:
    ''' restituisce il minore fra a e b '''
    if a < b:
        return a
    else:
        return b

m = minore(12,8)
print('minore', m)


# In[ ]:


# funzione che restituisce più valori
def min_max_med(a: float, b: float) -> tuple:
    ''' restituisce minore, maggiore, media '''
    if a < b:
        mi = a
        ma = b
    else:
        mi = b
        ma = a
    me = (a + b) / 2
    return mi,ma,me

print(min_max_med(23,12))


# ### esempio risolto
# La funzione distanza riceve come parametri le coordinate di un punto sul piano cartesiano e restituisce la distanza dall'origine.
# Generare casualmente le coordinate di 10 punti e per ognuno di questi visualizzare la sua distanza dall'origine.

# In[ ]:


import math
import random

def distanza(x: float, y: float) -> float:
    """
    calcola la distanza dall'origine degli assi cartesiano
        Parameters:
            x (float) ascissa del punto
            y (float) ordinata del punto
        Returns:
            (float) distanza del punto dall'origine
    """
    d = math.sqrt(x**2+y**2)
    return d

def main():
    c = 1
    while c <= 10:
        print('punto numero',c)
        cx = random.randint(-100,100) / 10
        cy = random.randint(-100,100) / 10   
        print("distanza dall'origine del punto",cx,cy,'=',distanza(cx,cy))
        c = c + 1
    
main()


# #### esempio 

# Scommesse ippiche
# 
# Scrivere un programma che simula un sistema di scommesse presso un ippodromo. 
# 
# Il giocatore ha un importo iniziale di 100 euro e ogni puntata costa 5 euro. 
# 
# È possibile puntare su un cavallo come piazzato (si vince se il cavallo arriva primo o secondo o terzo) o come vincente (si vince se arriva primo). 
# 
# La vincita per un cavallo piazzato è di 10 euro e per un vincente di 50 euro. 
# 
# I cavalli sono individuati dal loro numero (da 1 a 10), quado si punta si deve scegliere il numero del cavallo (controllare che sia un valore accettabile). 
# 
# L’ordine di arrivo deve essere simulato mediante generazione di valori casuali. 
# 
# Il programma termina quando il giocatore ha esaurito il suo importo o quando decide di non continuare a scommettere. 
# 
# Al termine visualizzare quante scommesse sono state effettuate e l’importo finale del giocatore.

# In[ ]:


from random import randint

importo = 100    # importo iniziale
scommesse = 0    # numero di scommesse effettuate

continua = input('vuoi continuaere a scommettere (s,n)? ')
while continua == 's' and importo >= 5:
    cavallo = int(input('cavallo giocato (1,10): '))
    while cavallo < 1 or cavallo > 10:
        print('numero cavallo non corretto')
        cavallo = int(input('cavallo giocato (1,10): '))
    print('vincente (v) o piazzato (p)')
    scommesse += 1
    vp = input()
    importo -= 5
    if vp == 'v':     #puntato su cavallo vincente
        vincente = randint(1,10)    # cavallo vincente
        print('vincente',vincente)
        if cavallo == vincente:
            importo += 50
    else:
        v1 = randint(1,10)      # primo
        v2 = randint(1,10)      # secondo
        v3 = randint(1,10)      # terzo
        print('piazzati',v1,v2,v3)
        # to do verificare che v1 diverso da v2 e da v3 ...
        if cavallo == v1 or cavallo == v2 or cavallo == v3:
            importo += 10
    print('giocata numero',scommesse,'importo',importo)
    continua = input('vuoi continuare a scommettere (s,n)? ')

print('effettuate',scommesse,'scommesse importo',importo)

