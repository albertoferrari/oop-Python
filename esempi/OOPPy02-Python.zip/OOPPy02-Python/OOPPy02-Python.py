
print(type(2))
print(type(2.0))
print(type('hello'))
print(type(True))


# In[ ]:


print("2  * 5 = ", 2  * 5)
print("2 ** 5 = ", 2 ** 5)
print("2 ** 0.5 = ", 2 ** 0.5)
print("28 // 7 = ",28 // 7)
print("28  % 7 = ",28  % 7)
print("28  / 7 = ",28  / 7)
print("3 >  3 = ",3 >  3)
print("3 >= 3 = ",3 >= 3)
print("True and False = ", True and False)
print("True  or False = ", True  or False)
print("not True = ", not True)


# In[ ]:


print("2 ** 1000 = ", 2 ** 1000)  # no limits (but memory)


# ### tipi immutabili

# In[ ]:


# float tipo immutabile
v1 = 4.5
print("v1 =",v1)
print("tipo      della variabile v1",type(v1))
print("indirizzo della variabile v1",id(v1))
v1 = 5    # assegnamento nuovo valore
print("v1 =",v1)
print("tipo      della variabile v1",type(v1))
print("indirizzo della variabile v1",id(v1))


# In[ ]:


# assegnamento modifica il valore e il tipo
v1 = 10
print("v1 = ",v1)
print("tipo      della variabile v1",type(v1))
print("indirizzo della variabile v1",id(v1))
v1 = 5.5    # assegnamento nuovo valore
print("tipo      della variabile v1",type(v1))
print("indirizzo della variabile v1",id(v1))


# In[ ]:


# str tipo immutabile
v1 = "hello"
print("tipo      della variabile v1",type(v1))
print("indirizzo della variabile v1",id(v1))
v1 = "world"    # assegnamento nuovo valore
print("indirizzo della variabile v1",id(v1))


# In[ ]:


# bool tipo immutabile ?!?
v1 = True
print("tipo      della variabile v1",type(v1))
print("indirizzo della variabile v1",id(v1))
v1 = False
print("indirizzo della variabile v1",id(v1))
v2 = True
print("indirizzo della variabile v2",id(v2))
v3 = False
print("indirizzo della variabile v3",id(v3))


# In[ ]:


# tuple tipo immutabile
v2 = (1,3,5)
print("v2",v2)
print("tipo      della variabile v2",type(v2))
print("indirizzo della variabile v2",id(v2))
v2 = v2 + (7,9)
print("indirizzo della variabile v2",id(v2))
print("v2",v2)


# ### tipi mutabili

# In[ ]:


# list
v3 = [1,3,5]
print("v3",v3)
print("tipo      della variabile v3",type(v3))
print("indirizzo della variabile v3",id(v3))
v3.append(7)
print("indirizzo della variabile v3",id(v3))
print("v3",v3)


# ### stringhe

# In[ ]:


s1 = "Monty Python's"    # apici o doppi apici per deliminitare stringhe
s2 = 'Flying Circus'
s3 = s1 + ' ' + s2       # concatenazione
print(s3)
s3 = s3.replace('o','_') # sostituzione di tutte le occorrenze
print(s3)
s3 = s3.replace('s','*')
print(s3)


# In[ ]:


print("'first' < 'second' = ",'first' < 'second')
print("'first' < 'Second' = ",'first' < 'Second')
print("chr(90) = ",chr(90))
print("ord('Z') = ",ord('Z'))


# ## input
# la funzione input restituisce una stringa proveniente dallo standard input (tastiera)
# 
# funzioni di casting permettono la conversione in altri tipi di dato

# In[ ]:


a = input('primo inserimento: ')
print('valore inserito',a,'di tipo',type(a))


# In[ ]:


b = int(input('secondo inserimento: '))
print('valore inserito',b,'di tipo',type(b))


# In[ ]:


c = list(input('terzo inserimento: '))
print('valore inserito',c,'di tipo',type(c))


# ## controllo del flusso di esecuzione

# ### if
# il blocco di codice che fa parte dell'if va indentato

# In[ ]:


età = int(input("inserisci la tua età "))
if età < 14:
    print("Sei troppo giovane per guidare uno scooter...")
    print("Ma non per imparare Python!")
print('fine programma')


# ### if --- else
# anche il blocco else va indentato

# #### esempio
# controllo se un numero intero è positivo e, se positivo, se è pari o dispari

# In[ ]:


# richiesta del valore
n = int(input('inserisci un valore intero: '))
if n > 0:
    if (n % 2) == 0:
        print(n,'è positivo e pari')
    else:
        print(n,'è positivo e dispari')
else:
    print(n,'non è positivo')
print('fine')


# #### esempio
# calcolo del valore assoluto (in realtà esiste una funzione che lo fa)

# In[ ]:


x = float(input("inserisci un valore: "))

if x >= 0:
    y = x
    print(x, "è positivo")
else:
    y = -x
    print(x, "è negativo")

print("il valore assoluto di",x,"è", y)


# #### connettivi logici nella clausola
# #### esempio
# calcolo età

# In[ ]:


print('data di nascita')
anno_n = int(input("anno: "))
mese_n = int(input("mese: "))
giorno_n = int(input("giorno: "))
print('data corrente')
anno_c = int(input("anno: "))
mese_c = int(input("mese: "))
giorno_c = int(input("giorno: "))

if (mese_c > mese_n
    or (mese_c == mese_n and giorno_c >= giorno_n)):
    età = anno_c - anno_n
else:
    età = anno_c - anno_n - 1

print("la tua età è", età, "anni")


# ##### ovviamente c'è un metodo migliore per gestire le date
# ma lo vedremo nelle prossime lezioni

# In[ ]:


from datetime import date

oggi = date.today() 

print("giorno:", oggi.day)
print("mese:", oggi.month)
print("anno:", oggi.year)


# ### elif (else if)

# #### esempio
# confronto stringhe

# In[ ]:


a = input("prima parola ")
b = input("seconda parola ")

if a < b:
    print("le parole sono ordinate in modo crescente")
elif a > b:
    print("le parole sono ordinate in modo decrescente")
else:
    print("le parole sono uguali")


# #### esempio
# scelta operatore

# In[ ]:


a = float(input('primo valore: '))
b = float(input('secondo valore: '))
op = input('operazione (+-*/%): ')

if op == '+':
    print(a + b)
elif op == '-':
    print(a - b)
elif op == '*':
    print(a * b)
elif op == '/' and b != 0:
    print(a / b)
elif op == '%':
    print(a % b)
else:
    print("Operazione non ammessa")


# ### while
# il blocco di codice del while va indentato

# #### eempio
# somma dei numeri da 1 a n

# In[ ]:


totale = 0
contatore = 1
n = int(input("n: "))     # primo input

while contatore <= n:     # condizione per la prosecuzione
    # totale = totale + contatore
    totale += contatore
    # contatore = contatore + 1
    contatore += 1

print("La somma dei numeri da 1 a",n,"è",totale)


# #### esempio
# somma dei valori in input

# In[ ]:


n = int(input("quanti valori? "))
totale = 0
i = 0

while i < n:
    val = int(input("valore: "))

    totale += val  # totale = totale + val
    i += 1         # i = i + 1

print("La somma dei valori inseriti è", totale)


# #### ciclo con sentinella
# #### esempio
# somma dei valori inseriti termina quando si inserisce 0

# In[ ]:


somma = 0    # somma dei valori inseriti
c = 0        # contatore valori inseriti

val = int(input("valore (0 per terminare): "))

while val != 0:
    somma += val
    c += 1
    val = int(input("valore (0 per terminare): "))

if c != 0:
    print("la media dei valori inseriti è", somma / c)


# #### esempio
# verifica se un valore è un quadrato perfetto

# In[ ]:


n = 0
while n <= 0:
    n = int(input("inserisci un valore positivo: "))

r = 1    # possibile radice quadrata del valore inserito
while r * r < n:
    r += 1

if r * r == n:
    print(n,"è un quadrato perfetto e la sua radice è", r)
else:
    print(n,"non è un quadrato perfetto")


# ### esempi di esercizi svolti
# #### esercizio
# verificare se un numero intero è primo

# In[ ]:


n = int(input('inserisci un numero intero positivo: '))
trovato_divisore = False        # non ho trovato nessun divisore

pd = 2       # possibile divisore di n
while pd <= n ** 0.5 and not trovato_divisore:
    if (n % pd) == 0:           # ho trovato che pd è divisore di n
        trovato_divisore = True
    pd += 1         # passa al possibile divisore successivo    

if trovato_divisore:
    print(n,'non è primo')
else:
    print(n,'è primo')


# ### esercizio svolto
# Generare 4 valori casuali (a,b,c,d) nell’intervallo 0 – 999.9.
# 
# I valori generati devono essere numeri razionali con una sola cifra decimale (es 428.5) 
# 
# Dire se gli intervalli numerici a..b e c..d si intersecano (hanno valori in comune)
# 

# In[ ]:


from random import randint
a = randint(0,9999) / 10
b = randint(0,9999) / 10
c = randint(0,9999) / 10
d = randint(0,9999) / 10
print(a,b,c,d)
s1min = min(a,b)
s1max = max(a,b)
s2min = min(c,d)
s2max = max(c,d)
print(s1min,s1max)
print(s2min,s2max)
if s2min <= s1min <= s2max or s2min <= s1max <= s2max:
    print('si')
elif s1min <= s2min <= s1max or s1min <= s2max <= s1max:
    print('si')
else:
    print('no')


# ### esercizio svolto
# Classificazione triangoli
# Scrivere un programma che riceve in input le misure dei lati di un triangolo e verifica se:
# - Il triangolo non esiste
# - Il triangolo è equilatero
# - Il triangolo è isoscele
# - Il triangolo è scaleno
# - Nel caso di isoscele o scaleno verifica se è rettangolo
# 
# *Disuguaglianza triangolare*
# 
# *In matematica, la disuguaglianza triangolare afferma che, in un triangolo, la somma delle lunghezze di due lati è maggiore della lunghezza del terzo. Una sua conseguenza, la disuguaglianza triangolare inversa, afferma invece che la differenza tra le lunghezze dei due lati è minore della lunghezza del rimanente*

# In[ ]:


l1 = float(input('lato 1: '))
l2 = float(input('lato 2: '))
l3 = float(input('lato 3: '))
if l1 <= 0 or l2 <= 0 or l3 <= 0:
    print('lati negativi: il triangolo non esiste')
elif l1+l2<l3 or l1+l3<l2 or l2+l3<l1:
    print('la somma di due lati è minore del terzo: il triangolo non esiste')
elif l1 == l2 == l3:
    print('triagolo equilatero')
elif l1 == l2 or l1 == l3 or l2 == l3:
    print('triangolo isoscele')
    if l1**2+l2**2==l3**2 or l1**2+l3**2==l2**2 or l3**2+l2**2==l1**2:
        print('rettangolo')
else:
    print('triangolo scaleno')
    if l1**2+l2**2==l3**2 or l1**2+l3**2==l2**2 or l3**2+l2**2==l1**2:
        print('rettangolo')


# ### esercizio svolto
# La popolazione di un particolare batterio raddoppia ogni ora. 
# Scrivere un programma che richiede in input il numero di batteri all’inizio dell’esperimento e il numero di ore della durata dell’esperimento e visualizza il numero di batteri presenti ogni ora fino al termine dell’esperimento

# In[ ]:


batteri = int(input('numero di batteri iniziali: '))
ore = int(input('durata esperimento: '))
h = 0
while h < ore:
    h += 1
    batteri *= 2
    print('ore',h,'batteri',batteri)


# ### esercizio svolto
# Generare casualmente il valore n compreso nell’intervallo chiuso 3..10.
# 
# Richiedere poi il nome di n studenti. 
# 
# Visualizzare infine il nome dello studente che precede tutti gli altri in ordine alfabetico e la media della lunghezza dei nomi degli studenti.

# In[ ]:


from random import randint     # dal modulo random importa la funzione randint
n = randint(3,10)
print(n,'studenti')
smin = input('nome del primo studente: ')
ns = 1                         # ho chiesto il nome di 1 studente
somma = len(smin)              # numero di caratteri del nome del primo studente

# richiesta del nome degli altri studenti
while ns < n:
    s = input('nome studente: ')
    somma = somma + len(s)     # incremento la somma con il numero di caratteri del nome
    ns += 1                    # ho chiesto il nome di un altro studente
    if s < smin:
        smin = s               # ho trovato uno studente 'minore'
        
print('lo studente che precede gli altri in ordine alfabetico è',smin)
print('la lunghezza media dei nomi è',somma/n)

